/**
 * Auto Trading Bot Execution Engine
 * Handles position sizing, bracket orders (SL/TP), trailing stops,
 * real-time tick monitoring, and TradingView webhook execution.
 */

import {
  BotConfig,
  BotPosition,
  BotLogItem,
  TradeAlert,
} from '../types/trading';
import { soundAlert } from './soundAlert';

export interface BotState {
  config: BotConfig;
  positions: BotPosition[];
  closedPositions: BotPosition[];
  logs: BotLogItem[];
  totalTrades: number;
  winCount: number;
  lossCount: number;
  realizedPnl: number;
}

export const INITIAL_BOT_CONFIG: BotConfig = {
  botEnabled: true,
  status: 'RUNNING',
  mode: 'PAPER',
  initialBalance: 10000,
  currentBalance: 10000,
  riskPerTradePercent: 2.0,
  maxLeverage: 5,
  autoCloseOnOpposite: true,
  trailingStop: true,
  soundAlerts: true,
  webhookSecret: 'LUX_AUTO_BOT_KEY_2026',
  telegramChatId: '',
  telegramBotToken: '',
};

export class TradingBotEngine {
  public state: BotState;
  private listeners: (() => void)[] = [];

  constructor() {
    this.state = {
      config: { ...INITIAL_BOT_CONFIG },
      positions: [],
      closedPositions: [],
      logs: [
        {
          id: `log_init_${Date.now()}`,
          time: Date.now(),
          type: 'INFO',
          message: 'LuxAlgo Auto Trading Bot Engine initialized successfully.',
          messageKh: 'ម៉ាស៊ីន Bot ជួញដូរស្វ័យប្រវត្តិ LuxAlgo ត្រូវបានចាប់ផ្ដើមដោយជោគជ័យ។',
        },
      ],
      totalTrades: 0,
      winCount: 0,
      lossCount: 0,
      realizedPnl: 0,
    };
  }

  public subscribe(listener: () => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }

  public updateConfig(partial: Partial<BotConfig>) {
    this.state.config = { ...this.state.config, ...partial };
    soundAlert.enabled = this.state.config.soundAlerts;
    this.notify();
  }

  public resetBot() {
    this.state.positions = [];
    this.state.closedPositions = [];
    this.state.config.currentBalance = this.state.config.initialBalance;
    this.state.totalTrades = 0;
    this.state.winCount = 0;
    this.state.lossCount = 0;
    this.state.realizedPnl = 0;
    this.addLog(
      'INFO',
      'Bot reset to default balance ($10,000).',
      'បានកំណត់ Bot ឡើងវិញទៅទំហំដើម ($10,000)។'
    );
    this.notify();
  }

  private addLog(
    type: BotLogItem['type'],
    message: string,
    messageKh: string,
    details?: Record<string, any>
  ) {
    const item: BotLogItem = {
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      time: Date.now(),
      type,
      message,
      messageKh,
      details,
    };
    this.state.logs = [item, ...this.state.logs.slice(0, 99)];
  }

  /**
   * Process a new price tick for an asset
   */
  public processTick(symbol: string, currentPrice: number) {
    if (this.state.positions.length === 0) return;

    let stateChanged = false;
    const remainingPositions: BotPosition[] = [];

    for (const pos of this.state.positions) {
      if (pos.symbol !== symbol) {
        remainingPositions.push(pos);
        continue;
      }

      pos.currentPrice = currentPrice;
      const isBuy = pos.type === 'BUY';

      // Unrealized PnL
      const priceDelta = isBuy ? currentPrice - pos.entryPrice : pos.entryPrice - currentPrice;
      pos.unrealizedPnl = Number((priceDelta * pos.sizeUnits).toFixed(2));
      pos.unrealizedPnlPercent = Number(((priceDelta / pos.entryPrice) * 100).toFixed(2));

      // Trailing Stop to Break-even check (+1R)
      if (this.state.config.trailingStop) {
        const riskDistance = Math.abs(pos.entryPrice - pos.slPrice);
        if (priceDelta >= riskDistance && pos.slPrice !== pos.entryPrice) {
          pos.slPrice = pos.entryPrice;
          this.addLog(
            'INFO',
            `Trailing Stop: Moved SL to Break-even (${pos.entryPrice}) for ${pos.symbol} ${pos.type}`,
            `Trailing Stop: បានរំកិល SL មកចំណុចស្មើតម្លៃដើម Break-even (${pos.entryPrice}) សម្រាប់ ${pos.type}`
          );
          stateChanged = true;
        }
      }

      // Check Take Profit
      const hitTp = isBuy ? currentPrice >= pos.tpPrice : currentPrice <= pos.tpPrice;
      // Check Stop Loss
      const hitSl = isBuy ? currentPrice <= pos.slPrice : currentPrice >= pos.slPrice;

      if (hitTp) {
        // Closed at TP
        const realized = Number((Math.abs(pos.tpPrice - pos.entryPrice) * pos.sizeUnits).toFixed(2));
        this.closePosition(pos, pos.tpPrice, 'TAKE_PROFIT', realized);
        stateChanged = true;
      } else if (hitSl) {
        // Closed at SL
        const realized = -Number((Math.abs(pos.entryPrice - pos.slPrice) * pos.sizeUnits).toFixed(2));
        this.closePosition(pos, pos.slPrice, 'STOP_LOSS', realized);
        stateChanged = true;
      } else {
        remainingPositions.push(pos);
      }
    }

    if (stateChanged) {
      this.state.positions = remainingPositions;
      this.notify();
    }
  }

  /**
   * Closes a position and records profit/loss
   */
  public closePosition(
    pos: BotPosition,
    exitPrice: number,
    reason: BotPosition['closedReason'] = 'MANUAL_CLOSE',
    explicitRealized?: number
  ) {
    const isBuy = pos.type === 'BUY';
    const priceDelta = isBuy ? exitPrice - pos.entryPrice : pos.entryPrice - exitPrice;
    const realized = explicitRealized !== undefined ? explicitRealized : priceDelta * pos.sizeUnits;

    pos.status = 'CLOSED';
    pos.closedReason = reason;
    pos.exitPrice = exitPrice;
    pos.exitTime = Date.now();
    pos.realizedPnl = Number(realized.toFixed(2));

    this.state.config.currentBalance = Number(
      (this.state.config.currentBalance + realized).toFixed(2)
    );
    this.state.realizedPnl = Number((this.state.realizedPnl + realized).toFixed(2));
    this.state.totalTrades += 1;

    if (realized > 0) {
      this.state.winCount += 1;
      soundAlert.playTakeProfitSound();
      this.addLog(
        'TP_HIT',
        `TAKE PROFIT HIT: ${pos.symbol} ${pos.type} closed at $${exitPrice} (+${realized.toFixed(2)} USDT)`,
        `ទទួលបានប្រាក់ចំណេញ (TP): បិទបញ្ជា ${pos.symbol} ${pos.type} នៅតម្លៃ $${exitPrice} (ចំណេញ +${realized.toFixed(2)} USDT) 🎉`,
        { realized, exitPrice }
      );
    } else {
      this.state.lossCount += 1;
      soundAlert.playStopLossSound();
      this.addLog(
        'SL_HIT',
        `STOP LOSS HIT: ${pos.symbol} ${pos.type} closed at $${exitPrice} (${realized.toFixed(2)} USDT)`,
        `កាត់ខាត (SL): បិទបញ្ជា ${pos.symbol} ${pos.type} នៅតម្លៃ $${exitPrice} (${realized.toFixed(2)} USDT)`,
        { realized, exitPrice }
      );
    }

    this.state.closedPositions = [pos, ...this.state.closedPositions];
    this.state.positions = this.state.positions.filter((p) => p.id !== pos.id);
    this.notify();
  }

  /**
   * Executes a Buy or Sell signal triggered from indicator or webhook
   */
  public executeSignal(
    symbol: string,
    type: 'BUY' | 'SELL',
    entryPrice: number,
    slPrice: number,
    tpPrice: number,
    source: 'INDICATOR' | 'WEBHOOK' = 'INDICATOR'
  ) {
    if (!this.state.config.botEnabled || this.state.config.status !== 'RUNNING') {
      return;
    }

    // 1. Auto-close opposite positions if enabled
    if (this.state.config.autoCloseOnOpposite) {
      const oppositeType = type === 'BUY' ? 'SELL' : 'BUY';
      const opposites = this.state.positions.filter(
        (p) => p.symbol === symbol && p.type === oppositeType
      );
      opposites.forEach((op) => {
        this.closePosition(op, entryPrice, 'OPPOSITE_SIGNAL');
        this.addLog(
          'ORDER_CLOSE',
          `Closed opposite ${oppositeType} on new ${type} signal at $${entryPrice}`,
          `បានបិទបញ្ជាផ្ទុយ ${oppositeType} ដោយសារមានសញ្ញាថ្មី ${type} នៅតម្លៃ $${entryPrice}`
        );
      });
    }

    // 2. Prevent stacking identical direction if already open
    const existingSame = this.state.positions.find(
      (p) => p.symbol === symbol && p.type === type
    );
    if (existingSame) {
      // Already open in same direction
      return;
    }

    // 3. Position Sizing based on risk percentage
    const balance = this.state.config.currentBalance;
    const riskDollar = balance * (this.state.config.riskPerTradePercent / 100);
    const slDistance = Math.abs(entryPrice - slPrice);

    if (slDistance <= 0) return;

    let sizeUnits = riskDollar / slDistance;
    const allocatedMargin = Number(((sizeUnits * entryPrice) / this.state.config.maxLeverage).toFixed(2));

    // Cap by balance if exceeding margin
    if (allocatedMargin > balance * 0.95) {
      sizeUnits = (balance * 0.95 * this.state.config.maxLeverage) / entryPrice;
    }

    sizeUnits = Number(sizeUnits.toFixed(4));

    const newPosition: BotPosition = {
      id: `pos_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      symbol,
      type,
      entryPrice,
      currentPrice: entryPrice,
      slPrice,
      tpPrice,
      sizeUnits,
      allocatedMargin,
      unrealizedPnl: 0,
      unrealizedPnlPercent: 0,
      entryTime: Date.now(),
      status: 'OPEN',
    };

    this.state.positions.push(newPosition);

    if (type === 'BUY') {
      soundAlert.playBuySound();
      this.addLog(
        'ORDER_OPEN',
        `[AutoBot] BUY EXECUTED: ${symbol} @ $${entryPrice} | SL: $${slPrice} | TP: $${tpPrice} | Size: ${sizeUnits}`,
        `[Bot ស្វ័យប្រវត្តិ] បើកបញ្ជាទិញ BUY: ${symbol} @ $${entryPrice} | SL: $${slPrice} | TP: $${tpPrice} (ទំហំ: ${sizeUnits})`,
        { source, entryPrice, slPrice, tpPrice, sizeUnits }
      );
    } else {
      soundAlert.playSellSound();
      this.addLog(
        'ORDER_OPEN',
        `[AutoBot] SELL EXECUTED: ${symbol} @ $${entryPrice} | SL: $${slPrice} | TP: $${tpPrice} | Size: ${sizeUnits}`,
        `[Bot ស្វ័យប្រវត្តិ] បើកបញ្ជាលក់ SELL: ${symbol} @ $${entryPrice} | SL: $${slPrice} | TP: $${tpPrice} (ទំហំ: ${sizeUnits})`,
        { source, entryPrice, slPrice, tpPrice, sizeUnits }
      );
    }

    this.notify();
  }

  /**
   * Simulates incoming TradingView webhook payload
   */
  public handleWebhook(payload: {
    secret: string;
    symbol: string;
    action: 'BUY' | 'SELL';
    price: number;
    sl?: number;
    tp?: number;
  }): { success: boolean; message: string; messageKh: string } {
    if (payload.secret !== this.state.config.webhookSecret) {
      this.addLog(
        'ERROR',
        `Webhook Auth Failed: Invalid secret key`,
        `ការផ្ទៀងផ្ទាត់ Webhook បរាជ័យ: Secret Key មិនត្រឹមត្រូវ`
      );
      return {
        success: false,
        message: 'Invalid webhook secret key',
        messageKh: 'លេខកូដសំងាត់ Webhook Secret មិនត្រឹមត្រូវ',
      };
    }

    const price = Number(payload.price);
    const sl = payload.sl ? Number(payload.sl) : payload.action === 'BUY' ? price * 0.985 : price * 1.015;
    const tp = payload.tp ? Number(payload.tp) : payload.action === 'BUY' ? price + (price - sl) * 2 : price - (sl - price) * 2;

    this.addLog(
      'WEBHOOK_RECEIVED',
      `Webhook received from TradingView: ${payload.action} ${payload.symbol} @ $${price}`,
      `បានទទួលសញ្ញាពី TradingView Webhook: ${payload.action} ${payload.symbol} @ $${price}`
    );

    this.executeSignal(payload.symbol, payload.action, price, sl, tp, 'WEBHOOK');

    return {
      success: true,
      message: `Order ${payload.action} executed successfully`,
      messageKh: `បានអនុវត្តបញ្ជាទិញ/លក់ ${payload.action} ដោយជោគជ័យ`,
    };
  }
}

export const botEngine = new TradingBotEngine();
