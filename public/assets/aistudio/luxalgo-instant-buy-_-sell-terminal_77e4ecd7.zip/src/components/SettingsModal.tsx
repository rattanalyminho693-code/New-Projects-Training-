/**
 * Modal to customize LuxAlgo Indicator Settings
 */

import React from 'react';
import { IndicatorSettings, SignalMode, Language } from '../types/trading';
import { Sliders, X, RotateCcw } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: IndicatorSettings;
  onSave: (newSettings: IndicatorSettings) => void;
  onReset: () => void;
  lang: Language;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSave,
  onReset,
  lang,
}) => {
  if (!isOpen) return null;
  const isKhmer = lang === 'km';

  const [form, setForm] = React.useState<IndicatorSettings>({ ...settings });

  const signalModes: SignalMode[] = [
    'Fast Pivot (ចេញលឿន 1-Bar)',
    'Instant Breakout (ចេញភ្លាមៗ 0-Bar)',
    'Classic LuxAlgo (ដើម 24-Bar)',
  ];

  const handleApply = () => {
    onSave(form);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="w-full max-w-lg bg-[#0d121c] border border-slate-800 rounded-xl shadow-2xl overflow-hidden flex flex-col text-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-teal-400" />
            <h3 className="text-sm font-semibold text-slate-100">
              {isKhmer
                ? 'ការកំណត់សូចនាករ LuxAlgo [ចេញភ្លាមៗ]'
                : 'LuxAlgo Indicator Settings'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-100 rounded transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex flex-col gap-4 text-xs overflow-y-auto max-h-[70vh]">
          {/* Signal Mode */}
          <div>
            <label className="block font-medium text-slate-300 mb-1">
              {isKhmer ? 'ប្រភេទសញ្ញា (Signal Mode)' : 'Signal Mode'}
            </label>
            <select
              value={form.signalMode}
              onChange={(e) =>
                setForm({ ...form, signalMode: e.target.value as SignalMode })
              }
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-100 font-mono text-xs focus:border-teal-500 focus:outline-none"
            >
              {signalModes.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </select>
          </div>

          {/* Left Bars */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-medium text-slate-300 mb-1">
                {isKhmer ? 'Pivot Left Bars' : 'Pivot Left Bars'}
              </label>
              <input
                type="number"
                min="2"
                max="100"
                value={form.leftBars}
                onChange={(e) =>
                  setForm({ ...form, leftBars: parseInt(e.target.value, 10) || 12 })
                }
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-100 font-mono text-xs"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                {isKhmer ? 'លំនាំដើម: 12' : 'Default: 12'}
              </span>
            </div>

            <div>
              <label className="block font-medium text-slate-300 mb-1">
                {isKhmer ? 'Pivot Right Bars' : 'Pivot Right Bars'}
              </label>
              <input
                type="number"
                min="1"
                max="50"
                value={form.rightBars}
                onChange={(e) =>
                  setForm({ ...form, rightBars: parseInt(e.target.value, 10) || 1 })
                }
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-100 font-mono text-xs"
              />
              <span className="text-[10px] text-teal-400 mt-1 block">
                {isKhmer ? '1 = ចេញភ្លាមៗបន្ទាប់ពី 1 ទាន' : '1 = Instant 1-bar delay'}
              </span>
            </div>
          </div>

          {/* Risk Reward Ratio */}
          <div>
            <label className="block font-medium text-slate-300 mb-1">
              {isKhmer ? 'មេគុណ Risk-Reward Ratio (TP)' : 'Risk-Reward Ratio (TP Multiplier)'}
            </label>
            <div className="flex items-center gap-3">
              <input
                type="number"
                step="0.1"
                min="0.5"
                max="10"
                value={form.rrRatio}
                onChange={(e) =>
                  setForm({ ...form, rrRatio: parseFloat(e.target.value) || 2.0 })
                }
                className="w-24 px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-100 font-mono text-xs"
              />
              <span className="text-slate-400 text-[11px]">
                {isKhmer ? 'ឧទាហរណ៍: 2.0 (ចំណេញ 2 ដងនៃការកាត់ខាត)' : 'e.g. 2.0 means TP = 2x Risk distance'}
              </span>
            </div>
          </div>

          {/* Backpaint checkbox */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
            <div>
              <div className="font-medium text-slate-200">
                {isKhmer ? 'Backpaint Mode' : 'Backpaint Offset'}
              </div>
              <div className="text-[11px] text-slate-400">
                {isKhmer ? 'បង្ហាញបន្ទាត់ត្រឡប់ទៅអតីតកាល' : 'Offsets lines into the past'}
              </div>
            </div>
            <input
              type="checkbox"
              checked={form.backpaint}
              onChange={(e) => setForm({ ...form, backpaint: e.target.checked })}
              className="w-4 h-4 rounded text-teal-600 bg-slate-900 border-slate-700 cursor-pointer accent-teal-500"
            />
          </div>

          {/* Style Colors */}
          <div className="pt-2 border-t border-slate-800 flex flex-col gap-3">
            <span className="font-medium text-slate-200">
              {isKhmer ? 'ពណ៌បន្ទាត់ និងផ្ទៃ (Visual Styles)' : 'Style Colors'}
            </span>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <span className="text-[10px] text-slate-400 block mb-1">Trailing Max</span>
                <input
                  type="color"
                  value={form.maxCss}
                  onChange={(e) => setForm({ ...form, maxCss: e.target.value })}
                  className="w-full h-8 bg-slate-900 border border-slate-700 rounded cursor-pointer"
                />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block mb-1">Trailing Min</span>
                <input
                  type="color"
                  value={form.minCss}
                  onChange={(e) => setForm({ ...form, minCss: e.target.value })}
                  className="w-full h-8 bg-slate-900 border border-slate-700 rounded cursor-pointer"
                />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block mb-1">Trailing Avg</span>
                <input
                  type="color"
                  value={form.avgCss}
                  onChange={(e) => setForm({ ...form, avgCss: e.target.value })}
                  className="w-full h-8 bg-slate-900 border border-slate-700 rounded cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-[#090d14] border-t border-slate-800">
          <button
            onClick={() => {
              onReset();
              onClose();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-slate-400 hover:text-slate-200 text-xs transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{isKhmer ? 'កំណត់លំនាំដើម' : 'Reset Defaults'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded transition-colors"
            >
              {isKhmer ? 'បោះបង់' : 'Cancel'}
            </button>
            <button
              onClick={handleApply}
              className="px-4 py-1.5 bg-teal-600 hover:bg-teal-500 text-white text-xs font-medium rounded transition-colors"
            >
              {isKhmer ? 'យល់ព្រមអនុវត្ត' : 'Apply Settings'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
