/**
 * Real-time Alerts Feed & Notification Monitor
 */

import React from 'react';
import { TradeAlert, Language } from '../types/trading';
import { Bell, BellOff, Volume2, VolumeX, CheckCircle, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { soundAlert } from '../services/soundAlert';

interface AlertsPanelProps {
  alerts: TradeAlert[];
  soundEnabled: boolean;
  onToggleSound: () => void;
  decimals?: number;
  lang: Language;
}

export const AlertsPanel: React.FC<AlertsPanelProps> = ({
  alerts,
  soundEnabled,
  onToggleSound,
  decimals = 2,
  lang,
}) => {
  const isKhmer = lang === 'km';

  return (
    <div className="flex flex-col gap-6 text-slate-200">
      {/* Top Banner */}
      <div className="flex items-center justify-between p-4 bg-[#0d121c] border border-slate-800 rounded-lg">
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-teal-400" />
          <h3 className="text-sm font-semibold text-slate-100">
            {isKhmer
              ? 'ការជូនដំណឹងសញ្ញាផ្ទាល់ (Instant Signal Alerts Feed)'
              : 'Real-Time Trading Alerts Feed'}
          </h3>
          <span className="text-xs font-mono text-slate-400">
            ({alerts.length} {isKhmer ? 'សញ្ញា' : 'signals'})
          </span>
        </div>

        <button
          onClick={onToggleSound}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium border transition-colors ${
            soundEnabled
              ? 'bg-teal-950/60 border-teal-800 text-teal-300 hover:bg-teal-900/60'
              : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
          }`}
        >
          {soundEnabled ? (
            <>
              <Volume2 className="w-3.5 h-3.5" />
              <span>{isKhmer ? 'សំឡេង: បើក' : 'Sound: ON'}</span>
            </>
          ) : (
            <>
              <VolumeX className="w-3.5 h-3.5" />
              <span>{isKhmer ? 'សំឡេង: បិទ' : 'Sound: OFF'}</span>
            </>
          )}
        </button>
      </div>

      {/* Alerts Stream List */}
      <div className="flex flex-col gap-3">
        {alerts.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-500 bg-[#0d121c] border border-dashed border-slate-800 rounded-lg">
            {isKhmer
              ? 'មិនទាន់មានសញ្ញាថ្មីត្រូវបានកត់ត្រានៅឡើយ។ នៅពេលសញ្ញា BUY ឬ SELL ចេញ វានឹងបង្ហាញនៅទីនេះភ្លាមៗ!'
              : 'No alerts triggered yet. As soon as a BUY or SELL signal occurs, it will display here instantly!'}
          </div>
        ) : (
          alerts.map((al) => {
            const isBuy = al.type === 'BUY';
            const timeStr = new Date(al.time).toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
              second: '2-digit',
            });
            const dateStr = new Date(al.time).toLocaleDateString([], {
              month: 'short',
              day: 'numeric',
            });

            return (
              <div
                key={al.id}
                className={`p-4 rounded-lg border flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all ${
                  isBuy
                    ? 'bg-teal-950/20 border-teal-800/80 hover:border-teal-700'
                    : 'bg-rose-950/20 border-rose-800/80 hover:border-rose-700'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`p-2 rounded-md shrink-0 ${
                      isBuy ? 'bg-teal-900/60 text-teal-300' : 'bg-rose-900/60 text-rose-300'
                    }`}
                  >
                    {isBuy ? (
                      <ArrowUpRight className="w-5 h-5" />
                    ) : (
                      <ArrowDownRight className="w-5 h-5" />
                    )}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-xs font-bold px-2 py-0.5 rounded font-mono ${
                          isBuy
                            ? 'bg-teal-900 text-teal-200 border border-teal-700'
                            : 'bg-rose-900 text-rose-200 border border-rose-700'
                        }`}
                      >
                        {al.type} SIGNAL
                      </span>
                      <span className="font-bold text-slate-100 font-mono text-sm">
                        {al.symbol}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">[{al.timeframe}]</span>
                    </div>

                    <div className="text-xs text-slate-300 mt-1.5 font-mono">
                      {isKhmer
                        ? `សញ្ញា LuxAlgo [ចេញភ្លាមៗ]: ចូលទិញ/លក់ @ $${al.entryPrice.toFixed(
                            decimals
                          )}`
                        : `LuxAlgo Instant Signal: Entry @ $${al.entryPrice.toFixed(decimals)}`}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-xs font-mono">
                  <div className="flex flex-col items-end">
                    <span className="text-rose-400">
                      SL: ${al.slPrice.toFixed(decimals)}
                    </span>
                    <span className="text-emerald-400">
                      TP: ${al.tpPrice.toFixed(decimals)}
                    </span>
                  </div>

                  <div className="text-right text-slate-400 text-[11px] border-l border-slate-800 pl-4">
                    <div>{timeStr}</div>
                    <div>{dateStr}</div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
