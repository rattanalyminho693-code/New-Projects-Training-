/**
 * High-DPI Interactive Candlestick Chart for LuxAlgo Instant Buy/Sell Indicator
 * With Trailing Max/Min Channels, Channel Area Fill, Buy/Sell Signals, and Bot Bracket Orders
 */

import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Candle, IndicatorBarData, IndicatorSettings, BotPosition } from '../types/trading';
import { ZoomIn, ZoomOut, RotateCcw, Crosshair } from 'lucide-react';

interface TradingChartProps {
  candles: Candle[];
  indicatorData: IndicatorBarData[];
  settings: IndicatorSettings;
  activePositions: BotPosition[];
  selectedTradeIndex?: number | null;
  onSelectTrade?: (index: number) => void;
  decimals?: number;
  symbol: string;
}

export const TradingChart: React.FC<TradingChartProps> = ({
  candles,
  indicatorData,
  settings,
  activePositions,
  selectedTradeIndex,
  onSelectTrade,
  decimals = 2,
  symbol,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Viewport / zoom state
  const [visibleBars, setVisibleBars] = useState<number>(75);
  const [scrollOffset, setScrollOffset] = useState<number>(0); // 0 = rightmost (latest)
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const [mousePos, setMousePos] = useState<{ x: number; y: number } | null>(null);
  const isDraggingRef = useRef<boolean>(false);
  const dragStartXRef = useRef<number>(0);
  const dragStartOffsetRef = useRef<number>(0);

  // When selected trade changes from outside, scroll to it
  useEffect(() => {
    if (selectedTradeIndex !== undefined && selectedTradeIndex !== null && candles.length > 0) {
      const targetOffset = Math.max(0, candles.length - 1 - selectedTradeIndex - Math.floor(visibleBars / 2));
      setScrollOffset(targetOffset);
    }
  }, [selectedTradeIndex, candles.length, visibleBars]);

  // Main drawing routine
  const renderChart = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || candles.length === 0) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const width = canvas.width / dpr;
    const height = canvas.height / dpr;

    ctx.save();
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);

    // Padding & dimensions
    const rightMargin = 72; // Price axis
    const bottomMargin = 28; // Time axis
    const chartWidth = width - rightMargin;
    const chartHeight = height - bottomMargin;
    const volumeHeight = Math.min(80, chartHeight * 0.18);
    const priceChartHeight = chartHeight - volumeHeight - 10;

    // Background
    ctx.fillStyle = '#0c1017';
    ctx.fillRect(0, 0, width, height);

    // Calculate visible slice of candles
    const totalCandles = candles.length;
    const barsCount = Math.min(visibleBars, totalCandles);
    const endIndex = Math.max(0, totalCandles - scrollOffset);
    const startIndex = Math.max(0, endIndex - barsCount);
    const actualVisibleCount = endIndex - startIndex;

    if (actualVisibleCount <= 0) {
      ctx.restore();
      return;
    }

    const candleWidth = chartWidth / actualVisibleCount;
    const bodyWidth = Math.max(2, candleWidth * 0.72);

    // Find min and max price within visible slice
    let minPrice = Infinity;
    let maxPrice = -Infinity;
    let maxVolume = 0;

    for (let i = startIndex; i < endIndex; i++) {
      const c = candles[i];
      if (c.low < minPrice) minPrice = c.low;
      if (c.high > maxPrice) maxPrice = c.high;
      if (c.volume > maxVolume) maxVolume = c.volume;

      const ind = indicatorData[i];
      if (ind) {
        if (ind.max > maxPrice) maxPrice = ind.max;
        if (ind.min < minPrice) minPrice = ind.min;
      }
    }

    // Add padding to price range
    const priceRange = maxPrice - minPrice || 1;
    minPrice -= priceRange * 0.05;
    maxPrice += priceRange * 0.05;
    const adjustedRange = maxPrice - minPrice;

    // Coordinate conversion helpers
    const getY = (price: number) => {
      return priceChartHeight - ((price - minPrice) / adjustedRange) * priceChartHeight;
    };

    const getX = (index: number) => {
      const relIdx = index - startIndex;
      return relIdx * candleWidth + candleWidth / 2;
    };

    // Draw Grid Lines
    ctx.strokeStyle = '#18202f';
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 4]);

    const gridStepsY = 6;
    for (let i = 0; i <= gridStepsY; i++) {
      const y = (priceChartHeight / gridStepsY) * i;
      const price = maxPrice - (i / gridStepsY) * adjustedRange;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(chartWidth, y);
      ctx.stroke();

      // Price label on right axis
      ctx.fillStyle = '#64748b';
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillText(price.toFixed(decimals), chartWidth + 6, y + 3);
    }
    ctx.setLineDash([]);

    // 1. Draw Trailing Channel Polygon Fill (between max and min)
    if (indicatorData.length > 0) {
      ctx.beginPath();
      let first = true;
      for (let i = startIndex; i < endIndex; i++) {
        const ind = indicatorData[i];
        if (!ind) continue;
        const x = getX(i);
        const yMax = getY(ind.max);
        if (first) {
          ctx.moveTo(x, yMax);
          first = false;
        } else {
          ctx.lineTo(x, yMax);
        }
      }

      for (let i = endIndex - 1; i >= startIndex; i--) {
        const ind = indicatorData[i];
        if (!ind) continue;
        const x = getX(i);
        const yMin = getY(ind.min);
        ctx.lineTo(x, yMin);
      }
      ctx.closePath();

      // Trend color fill
      const lastVisibleTrend = indicatorData[endIndex - 1]?.trend || 'bull';
      ctx.fillStyle =
        lastVisibleTrend === 'bull' ? 'rgba(20, 184, 166, 0.12)' : 'rgba(239, 68, 68, 0.12)';
      ctx.fill();

      // 2. Draw Trailing Maximum Line (Teal)
      ctx.beginPath();
      ctx.strokeStyle = settings.maxCss || '#14b8a6';
      ctx.lineWidth = 1.8;
      for (let i = startIndex; i < endIndex; i++) {
        const ind = indicatorData[i];
        if (!ind) continue;
        const x = getX(i);
        const y = getY(ind.max);
        if (i === startIndex) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // 3. Draw Trailing Minimum Line (Red)
      ctx.beginPath();
      ctx.strokeStyle = settings.minCss || '#ef4444';
      ctx.lineWidth = 1.8;
      for (let i = startIndex; i < endIndex; i++) {
        const ind = indicatorData[i];
        if (!ind) continue;
        const x = getX(i);
        const y = getY(ind.min);
        if (i === startIndex) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // 4. Draw Trailing Average Line (Orange)
      ctx.beginPath();
      ctx.strokeStyle = settings.avgCss || '#ff5d00';
      ctx.lineWidth = 1.4;
      ctx.setLineDash([4, 3]);
      for (let i = startIndex; i < endIndex; i++) {
        const ind = indicatorData[i];
        if (!ind) continue;
        const x = getX(i);
        const y = getY(ind.avg);
        if (i === startIndex) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // 5. Draw Volume Bars
    const volBaseY = chartHeight;
    for (let i = startIndex; i < endIndex; i++) {
      const c = candles[i];
      const x = getX(i);
      const isUp = c.close >= c.open;
      const volHeight = maxVolume > 0 ? (c.volume / maxVolume) * volumeHeight : 0;
      ctx.fillStyle = isUp ? 'rgba(20, 184, 166, 0.25)' : 'rgba(239, 68, 68, 0.25)';
      ctx.fillRect(x - bodyWidth / 2, volBaseY - volHeight, bodyWidth, volHeight);
    }

    // 6. Draw Candlesticks
    for (let i = startIndex; i < endIndex; i++) {
      const c = candles[i];
      const x = getX(i);
      const isUp = c.close >= c.open;
      const color = isUp ? '#14b8a6' : '#ef4444';

      const yOpen = getY(c.open);
      const yClose = getY(c.close);
      const yHigh = getY(c.high);
      const yLow = getY(c.low);

      // Wick
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(x, yHigh);
      ctx.lineTo(x, yLow);
      ctx.stroke();

      // Body
      const bodyTop = Math.min(yOpen, yClose);
      const bodyHeight = Math.max(1.5, Math.abs(yClose - yOpen));
      ctx.fillStyle = color;
      ctx.fillRect(x - bodyWidth / 2, bodyTop, bodyWidth, bodyHeight);

      // 7. Draw Buy & Sell Signal Badges
      const ind = indicatorData[i];
      if (ind) {
        if (ind.isBuy) {
          // BUY Signal Label below candle
          const arrowY = yLow + 14;
          ctx.fillStyle = '#14b8a6';
          ctx.beginPath();
          ctx.moveTo(x, arrowY - 6);
          ctx.lineTo(x - 5, arrowY + 2);
          ctx.lineTo(x + 5, arrowY + 2);
          ctx.closePath();
          ctx.fill();

          // Small tag box
          ctx.fillStyle = '#115e59';
          ctx.strokeStyle = '#2dd4bf';
          ctx.lineWidth = 1;
          const tagW = 28;
          const tagH = 13;
          ctx.fillRect(x - tagW / 2, arrowY + 4, tagW, tagH);
          ctx.strokeRect(x - tagW / 2, arrowY + 4, tagW, tagH);

          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 8px "JetBrains Mono", sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('BUY', x, arrowY + 13);
        } else if (ind.isSell) {
          // SELL Signal Label above candle
          const arrowY = yHigh - 14;
          ctx.fillStyle = '#ef4444';
          ctx.beginPath();
          ctx.moveTo(x, arrowY + 6);
          ctx.lineTo(x - 5, arrowY - 2);
          ctx.lineTo(x + 5, arrowY - 2);
          ctx.closePath();
          ctx.fill();

          // Small tag box
          ctx.fillStyle = '#991b1b';
          ctx.strokeStyle = '#f87171';
          ctx.lineWidth = 1;
          const tagW = 32;
          const tagH = 13;
          ctx.fillRect(x - tagW / 2, arrowY - 17, tagW, tagH);
          ctx.strokeRect(x - tagW / 2, arrowY - 17, tagW, tagH);

          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 8px "JetBrains Mono", sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('SELL', x, arrowY - 8);
        }
      }
    }

    // 8. Draw Bot Active Positions (Bracket Orders: Entry, SL, TP)
    activePositions.forEach((pos) => {
      const yEntry = getY(pos.entryPrice);
      const ySl = getY(pos.slPrice);
      const yTp = getY(pos.tpPrice);

      // Entry line (Cyan)
      ctx.setLineDash([4, 4]);
      ctx.lineWidth = 1.4;
      ctx.strokeStyle = '#06b6d4';
      ctx.beginPath();
      ctx.moveTo(0, yEntry);
      ctx.lineTo(chartWidth, yEntry);
      ctx.stroke();

      // SL line (Rose)
      ctx.strokeStyle = '#f43f5e';
      ctx.beginPath();
      ctx.moveTo(0, ySl);
      ctx.lineTo(chartWidth, ySl);
      ctx.stroke();

      // TP line (Emerald)
      ctx.strokeStyle = '#10b981';
      ctx.beginPath();
      ctx.moveTo(0, yTp);
      ctx.lineTo(chartWidth, yTp);
      ctx.stroke();
      ctx.setLineDash([]);

      // Badges on right axis
      ctx.font = 'bold 9px "JetBrains Mono", monospace';
      ctx.textAlign = 'left';

      // Entry Badge
      ctx.fillStyle = '#0891b2';
      ctx.fillRect(chartWidth + 2, yEntry - 8, rightMargin - 4, 16);
      ctx.fillStyle = '#ffffff';
      ctx.fillText(`ENT:${pos.entryPrice.toFixed(decimals)}`, chartWidth + 5, yEntry + 4);

      // TP Badge
      ctx.fillStyle = '#059669';
      ctx.fillRect(chartWidth + 2, yTp - 8, rightMargin - 4, 16);
      ctx.fillStyle = '#ffffff';
      ctx.fillText(`TP:${pos.tpPrice.toFixed(decimals)}`, chartWidth + 5, yTp + 4);

      // SL Badge
      ctx.fillStyle = '#e11d48';
      ctx.fillRect(chartWidth + 2, ySl - 8, rightMargin - 4, 16);
      ctx.fillStyle = '#ffffff';
      ctx.fillText(`SL:${pos.slPrice.toFixed(decimals)}`, chartWidth + 5, ySl + 4);
    });

    // 9. Current Price Line (Pulse / Tag)
    const latestCandle = candles[candles.length - 1];
    if (latestCandle) {
      const yCurr = getY(latestCandle.close);
      ctx.setLineDash([2, 3]);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, yCurr);
      ctx.lineTo(chartWidth, yCurr);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = '#0284c7';
      ctx.fillRect(chartWidth + 1, yCurr - 9, rightMargin - 2, 18);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 10px "JetBrains Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillText(latestCandle.close.toFixed(decimals), chartWidth + 4, yCurr + 4);
    }

    // 10. Draw Crosshair & Time/Price Tooltips if hovering
    if (mousePos && mousePos.x < chartWidth && mousePos.y < chartHeight) {
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.45)';
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);

      // Vertical crosshair
      ctx.beginPath();
      ctx.moveTo(mousePos.x, 0);
      ctx.lineTo(mousePos.x, chartHeight);
      ctx.stroke();

      // Horizontal crosshair
      ctx.beginPath();
      ctx.moveTo(0, mousePos.y);
      ctx.lineTo(chartWidth, mousePos.y);
      ctx.stroke();
      ctx.setLineDash([]);

      // Price at mouse Y
      const hoverPrice = maxPrice - (mousePos.y / priceChartHeight) * adjustedRange;
      ctx.fillStyle = '#334155';
      ctx.fillRect(chartWidth + 2, mousePos.y - 8, rightMargin - 4, 16);
      ctx.fillStyle = '#f8fafc';
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillText(hoverPrice.toFixed(decimals), chartWidth + 5, mousePos.y + 4);

      // Date at mouse X
      const hoveredBarIndex = Math.min(
        endIndex - 1,
        Math.max(startIndex, startIndex + Math.floor(mousePos.x / candleWidth))
      );
      const hoveredCandle = candles[hoveredBarIndex];
      if (hoveredCandle) {
        const timeStr = new Date(hoveredCandle.time).toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        });
        const dateStr = new Date(hoveredCandle.time).toLocaleDateString([], {
          month: 'short',
          day: 'numeric',
        });
        const text = `${dateStr} ${timeStr}`;
        ctx.fillStyle = '#334155';
        ctx.fillRect(mousePos.x - 45, chartHeight + 4, 90, 18);
        ctx.fillStyle = '#f8fafc';
        ctx.font = '10px "JetBrains Mono", monospace';
        ctx.textAlign = 'center';
        ctx.fillText(text, mousePos.x, chartHeight + 17);
      }
    }

    // 11. Time Axis labels
    const timeStep = Math.max(1, Math.floor(actualVisibleCount / 7));
    ctx.fillStyle = '#64748b';
    ctx.font = '10px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';

    for (let i = startIndex; i < endIndex; i += timeStep) {
      const c = candles[i];
      const x = getX(i);
      const label = new Date(c.time).toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      });
      ctx.fillText(label, x, chartHeight + 16);
    }

    ctx.restore();
  }, [
    candles,
    indicatorData,
    settings,
    activePositions,
    visibleBars,
    scrollOffset,
    mousePos,
    decimals,
  ]);

  // Sync canvas size on window resize
  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container) return;

      const dpr = window.devicePixelRatio || 1;
      const rect = container.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = `${rect.height}px`;

      renderChart();
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [renderChart]);

  useEffect(() => {
    renderChart();
  }, [renderChart]);

  // Mouse event handlers
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    isDraggingRef.current = true;
    dragStartXRef.current = e.clientX;
    dragStartOffsetRef.current = scrollOffset;
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setMousePos({ x, y });

    // Identify hovered bar index
    const chartWidth = rect.width - 72;
    const actualVisibleCount = Math.min(visibleBars, candles.length);
    const candleWidth = chartWidth / actualVisibleCount;
    const endIndex = Math.max(0, candles.length - scrollOffset);
    const startIndex = Math.max(0, endIndex - actualVisibleCount);
    const idx = startIndex + Math.floor(x / candleWidth);
    if (idx >= 0 && idx < candles.length) {
      setHoverIndex(idx);
    }

    // Dragging
    if (isDraggingRef.current) {
      const deltaX = e.clientX - dragStartXRef.current;
      const barsToShift = Math.round(deltaX / candleWidth);
      const newOffset = Math.max(0, Math.min(candles.length - 15, dragStartOffsetRef.current + barsToShift));
      setScrollOffset(newOffset);
    }
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    if (e.deltaY < 0) {
      // Zoom in
      setVisibleBars((prev) => Math.max(20, prev - 6));
    } else {
      // Zoom out
      setVisibleBars((prev) => Math.min(Math.min(300, candles.length), prev + 6));
    }
  };

  // Inspect data for header stats
  const activeCandle =
    hoverIndex !== null && candles[hoverIndex]
      ? candles[hoverIndex]
      : candles[candles.length - 1];
  const activeIndicator =
    hoverIndex !== null && indicatorData[hoverIndex]
      ? indicatorData[hoverIndex]
      : indicatorData[indicatorData.length - 1];

  return (
    <div className="relative flex flex-col h-full w-full bg-[#0c1017] select-none border border-slate-800 rounded-lg overflow-hidden">
      {/* Chart Top Status Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 bg-[#090d14] border-b border-slate-800 text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 font-mono">
            <span className="font-bold text-slate-100">{symbol}</span>
            <span className="text-slate-400">·</span>
            <span className="text-teal-400 font-semibold">{settings.signalMode.split(' ')[0]}</span>
          </div>

          {activeCandle && (
            <div className="flex items-center gap-3 font-mono text-[11px] text-slate-400">
              <span>
                O: <span className="text-slate-200">{activeCandle.open.toFixed(decimals)}</span>
              </span>
              <span>
                H: <span className="text-emerald-400">{activeCandle.high.toFixed(decimals)}</span>
              </span>
              <span>
                L: <span className="text-rose-400">{activeCandle.low.toFixed(decimals)}</span>
              </span>
              <span>
                C: <span className="text-slate-200">{activeCandle.close.toFixed(decimals)}</span>
              </span>
              <span>
                Vol: <span className="text-slate-300">{activeCandle.volume.toLocaleString()}</span>
              </span>
            </div>
          )}
        </div>

        {/* Trailing Max/Min/Avg Indicators */}
        {activeIndicator && (
          <div className="flex items-center gap-3 font-mono text-[11px]">
            <span className="text-teal-400">
              Max: {activeIndicator.max.toFixed(decimals)}
            </span>
            <span className="text-rose-400">
              Min: {activeIndicator.min.toFixed(decimals)}
            </span>
            <span className="text-amber-400">
              Avg: {activeIndicator.avg.toFixed(decimals)}
            </span>
            <span
              className={`px-1.5 py-0.5 rounded text-[10px] uppercase font-bold ${
                activeIndicator.trend === 'bull'
                  ? 'bg-teal-950 text-teal-300 border border-teal-800'
                  : 'bg-rose-950 text-rose-300 border border-rose-800'
              }`}
            >
              {activeIndicator.trend === 'bull' ? 'Uptrend (Bull)' : 'Downtrend (Bear)'}
            </span>
          </div>
        )}
      </div>

      {/* Main Canvas Area */}
      <div ref={containerRef} className="relative flex-1 w-full min-h-[380px] overflow-hidden cursor-crosshair">
        <canvas
          ref={canvasRef}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={() => {
            handleMouseUp();
            setMousePos(null);
          }}
          onWheel={handleWheel}
          className="absolute inset-0 block w-full h-full"
        />

        {/* Quick Zoom Controls Floating Overlay */}
        <div className="absolute bottom-10 right-20 flex items-center gap-1 bg-[#131a26]/90 backdrop-blur border border-slate-700/80 rounded px-1.5 py-1 text-slate-300 shadow-md">
          <button
            onClick={() => setVisibleBars((prev) => Math.max(20, prev - 10))}
            title="Zoom In"
            className="p-1 hover:text-white hover:bg-slate-700/60 rounded transition-colors"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setVisibleBars((prev) => Math.min(candles.length, prev + 10))}
            title="Zoom Out"
            className="p-1 hover:text-white hover:bg-slate-700/60 rounded transition-colors"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => {
              setScrollOffset(0);
              setVisibleBars(75);
            }}
            title="Reset to Latest"
            className="p-1 hover:text-white hover:bg-slate-700/60 rounded transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
