/**
 * Auto Trading Bot Control Center & Webhook Integration Panel
 * Full Khmer (ភាសាខ្មែរ) & English bilingual support for Auto Trading Bot
 */

import React, { useState } from 'react';
import {
  BotConfig,
  BotPosition,
  BotLogItem,
  Language,
} from '../types/trading';
import { botEngine } from '../services/tradingBotEngine';
import {
  Bot,
  Play,
  Pause,
  RotateCcw,
  ShieldCheck,
  Send,
  Code,
  Terminal,
  Copy,
  Check,
  DollarSign,
  TrendingUp,
  AlertTriangle,
  Zap,
} from 'lucide-react';

interface AutoTradingBotPanelProps {
  config: BotConfig;
  positions: BotPosition[];
  closedPositions: BotPosition[];
  logs: BotLogItem[];
  currentPrice: number;
  symbol: string;
  lang: Language;
}

export const AutoTradingBotPanel: React.FC<AutoTradingBotPanelProps> = ({
  config,
  positions,
  closedPositions,
  logs,
  currentPrice,
  symbol,
  lang,
}) => {
  const isKhmer = lang === 'km';
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [activeCodeTab, setActiveCodeTab] = useState<'python' | 'nodejs'>('python');

  // Test Webhook form state
  const [testAction, setTestAction] = useState<'BUY' | 'SELL'>('BUY');
  const [testPrice, setTestPrice] = useState<number>(currentPrice);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleToggleBot = () => {
    const nextStatus = config.status === 'RUNNING' ? 'PAUSED' : 'RUNNING';
    botEngine.updateConfig({
      status: nextStatus,
      botEnabled: nextStatus === 'RUNNING',
    });
  };

  const handleManualTestSignal = () => {
    const price = testPrice || currentPrice;
    const sl = testAction === 'BUY' ? price * 0.985 : price * 1.015;
    const tp = testAction === 'BUY' ? price + (price - sl) * 2 : price - (sl - price) * 2;

    botEngine.handleWebhook({
      secret: config.webhookSecret,
      symbol,
      action: testAction,
      price,
      sl: Number(sl.toFixed(2)),
      tp: Number(tp.toFixed(2)),
    });
  };

  const webhookJsonExample = `{
  "secret": "${config.webhookSecret}",
  "action": "{{strategy.order.action}}",
  "symbol": "${symbol}",
  "price": {{close}},
  "sl": {{low}},
  "tp": {{close}} + ({{close}} - {{low}}) * 2.0
}`;

  const pythonBotScript = `# ========================================================
# LuxAlgo Instant Auto Trading Bot (Binance / Bybit)
# ស្គ្រីប Python សម្រាប់ដំណើរការ Bot ជួញដូរស្វ័យប្រវត្តិ
# ========================================================
import ccxt
from fastapi import FastAPI, HTTPException, Request
import uvicorn
import json

app = FastAPI(title="LuxAlgo Auto Trading Bot Bridge")

# 1. Exchange API Setup (Use Testnet first!)
exchange = ccxt.binance({
    'apiKey': 'YOUR_BINANCE_API_KEY',
    'secret': 'YOUR_BINANCE_SECRET_KEY',
    'enableRateLimit': True,
    'options': {'defaultType': 'future'} # or 'spot'
})

WEBHOOK_SECRET = "${config.webhookSecret}"

@app.post("/webhook")
async def tradingview_webhook(request: Request):
    try:
        data = await request.json()
        print(f"[*] Received Webhook: {data}")

        # Check authentication secret
        if data.get("secret") != WEBHOOK_SECRET:
            raise HTTPException(status_code=401, detail="Unauthorized Secret")

        symbol = data.get("symbol", "BTC/USDT")
        action = data.get("action").upper() # 'BUY' or 'SELL'
        price = float(data.get("price"))
        sl = float(data.get("sl", price * 0.985 if action == "BUY" else price * 1.015))
        tp = float(data.get("tp", price * 1.03 if action == "BUY" else price * 0.97))

        side = 'buy' if action == 'BUY' else 'sell'
        
        # Calculate position size: 2% risk of balance
        balance = exchange.fetch_balance()['USDT']['free']
        risk_amount = balance * ${config.riskPerTradePercent / 100}
        risk_per_unit = abs(price - sl)
        units = round(risk_amount / risk_per_unit, 4)

        print(f"[+] Executing {action} {symbol} | Units: {units} | Entry: {price} | SL: {sl} | TP: {tp}")

        # Execute Market Entry Order
        order = exchange.create_market_order(symbol, side, units)
        print(f"[✓] Entry Executed: {order['id']}")

        # Place Take-Profit Limit & Stop-Loss
        opposite_side = 'sell' if action == 'BUY' else 'buy'
        exchange.create_order(symbol, 'LIMIT', opposite_side, units, tp, {'reduceOnly': True})
        exchange.create_order(symbol, 'STOP_MARKET', opposite_side, units, None, {'stopPrice': sl, 'reduceOnly': True})

        return {"status": "success", "order_id": order["id"], "action": action}
    except Exception as e:
        print(f"[!] Error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
`;

  const nodeJsBotScript = `// ========================================================
// LuxAlgo Instant Auto Trading Bot (Node.js & Express)
// កូដ Node.js ទទួល Webhook និងដំណើរការបញ្ជាទិញស្វ័យប្រវត្តិ
// ========================================================
const express = require('express');
const ccxt = require('ccxt');

const app = express();
app.use(express.json());

const exchange = new ccxt.binance({
  apiKey: process.env.BINANCE_API_KEY || 'YOUR_API_KEY',
  secret: process.env.BINANCE_SECRET_KEY || 'YOUR_SECRET_KEY',
  enableRateLimit: true,
  options: { defaultType: 'future' }
});

const WEBHOOK_SECRET = "${config.webhookSecret}";

app.post('/webhook', async (req, res) => {
  try {
    const { secret, action, symbol, price, sl, tp } = req.body;

    if (secret !== WEBHOOK_SECRET) {
      return res.status(401).json({ error: 'Invalid Webhook Secret' });
    }

    console.log(\`[AutoBot] Received \${action} for \${symbol} at $\${price}\`);

    // Fetch free balance
    const balance = await exchange.fetchBalance();
    const freeUsdt = balance.USDT.free;
    const riskDollar = freeUsdt * 0.02; // 2% risk
    const units = parseFloat((riskDollar / Math.abs(price - sl)).toFixed(3));

    const side = action.toLowerCase(); // 'buy' or 'sell'
    const oppSide = side === 'buy' ? 'sell' : 'buy';

    // 1. Market Entry
    const entryOrder = await exchange.createMarketOrder(symbol, side, units);

    // 2. Bracket Orders: Take-Profit & Stop-Loss
    await exchange.createOrder(symbol, 'LIMIT', oppSide, units, tp, { reduceOnly: true });
    await exchange.createOrder(symbol, 'STOP_MARKET', oppSide, units, undefined, { stopPrice: sl, reduceOnly: true });

    res.json({ success: true, orderId: entryOrder.id });
  } catch (err) {
    console.error('Bot Error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

app.listen(8000, () => console.log('Auto Trading Bot listening on port 8000...'));
`;

  return (
    <div className="flex flex-col gap-6 text-slate-200">
      {/* Top Banner / Engine Status Bar */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-[#0d121c] border border-slate-800 rounded-lg">
        {/* Status & Master Button */}
        <div className="flex flex-col justify-between">
          <div className="flex items-center gap-2">
            <Bot className="w-5 h-5 text-teal-400" />
            <span className="font-semibold text-sm">
              {isKhmer ? 'ស្ថានភាព Bot ជួញដូរ' : 'Auto Bot Engine'}
            </span>
          </div>
          <div className="flex items-center gap-3 mt-3">
            <button
              onClick={handleToggleBot}
              className={`flex items-center gap-2 px-4 py-2 rounded-md font-semibold text-xs transition-colors ${
                config.status === 'RUNNING'
                  ? 'bg-rose-600 hover:bg-rose-500 text-white'
                  : 'bg-teal-600 hover:bg-teal-500 text-white'
              }`}
            >
              {config.status === 'RUNNING' ? (
                <>
                  <Pause className="w-4 h-4" />
                  {isKhmer ? 'ផ្អាក Bot (Pause)' : 'Pause Bot'}
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  {isKhmer ? 'ដំណើរការ Bot (Run)' : 'Start Bot'}
                </>
              )}
            </button>

            <button
              onClick={() => botEngine.resetBot()}
              className="flex items-center gap-1 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-md text-xs font-medium transition-colors"
              title="Reset Account Capital"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              {isKhmer ? 'កំណត់ឡើងវិញ' : 'Reset'}
            </button>
          </div>
        </div>

        {/* Balance & Margin */}
        <div className="p-3 bg-[#111724] border border-slate-800/80 rounded-md">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>{isKhmer ? 'សមតុល្យគណនី (Equity)' : 'Account Balance'}</span>
            <DollarSign className="w-3.5 h-3.5 text-teal-400" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-100 mt-1">
            ${config.currentBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {isKhmer ? 'ទុនចាប់ផ្ដើម:' : 'Initial:'} ${config.initialBalance.toLocaleString()} USDT
          </div>
        </div>

        {/* Realized PnL & Win Rate */}
        <div className="p-3 bg-[#111724] border border-slate-800/80 rounded-md">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>{isKhmer ? 'ប្រាក់ចំណេញសរុប (Net P&L)' : 'Total Realized P&L'}</span>
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div
            className={`text-xl font-bold font-mono mt-1 ${
              botEngine.state.realizedPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {botEngine.state.realizedPnl >= 0 ? '+' : ''}
            ${botEngine.state.realizedPnl.toFixed(2)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">
            {isKhmer ? 'អត្រាឈ្នះ:' : 'Win Rate:'}{' '}
            {botEngine.state.totalTrades > 0
              ? `${((botEngine.state.winCount / botEngine.state.totalTrades) * 100).toFixed(1)}%`
              : '0%'}
            {' · '}
            {botEngine.state.winCount}W / {botEngine.state.lossCount}L
          </div>
        </div>

        {/* Active Open Positions Count */}
        <div className="p-3 bg-[#111724] border border-slate-800/80 rounded-md">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>{isKhmer ? 'បញ្ជាកំពុងបើក (Open Orders)' : 'Active Positions'}</span>
            <Zap className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-100 mt-1">
            {positions.length}{' '}
            <span className="text-xs font-normal text-slate-400">
              {isKhmer ? 'បញ្ជា' : 'trades'}
            </span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {isKhmer ? 'របៀបជួញដូរ:' : 'Mode:'}{' '}
            <span className="text-teal-400 font-semibold">
              {config.mode === 'PAPER' ? (isKhmer ? 'សាកល្បងផ្ទាល់' : 'Paper Live') : 'Webhook'}
            </span>
          </div>
        </div>
      </div>

      {/* Active Open Positions Table */}
      <div className="flex flex-col p-4 bg-[#0d121c] border border-slate-800 rounded-lg">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-slate-100">
              {isKhmer ? 'បញ្ជាជួញដូរដែលកំពុងបើកដំណើរការ (Active Positions)' : 'Active Open Positions'}
            </span>
            <span className="text-xs font-mono text-teal-400 bg-teal-950/60 border border-teal-800/80 px-2 py-0.5 rounded">
              {positions.length}
            </span>
          </div>
          <span className="text-xs text-slate-400">
            {isKhmer ? 'គ្រប់គ្រង SL និង TP ដោយស្វ័យប្រវត្តិ' : 'Auto SL / TP Bracket Management'}
          </span>
        </div>

        {positions.length === 0 ? (
          <div className="p-6 text-center text-sm text-slate-500 border border-dashed border-slate-800 rounded-md bg-[#090d14]">
            {isKhmer
              ? 'មិនទាន់មានបញ្ជាជួញដូរកំពុងបើកទេ។ នៅពេលដែលសញ្ញា Buy ឬ Sell ចេញពី Indicator ឬ Webhook, Bot នឹងបើកបញ្ជាទិញ/លក់ភ្លាមៗ!'
              : 'No open positions currently. When a Buy or Sell signal triggers from the indicator or webhook, the bot will execute orders instantly!'}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2 px-3">{isKhmer ? 'គូររូបិយប័ណ្ណ' : 'Symbol'}</th>
                  <th className="py-2 px-3">{isKhmer ? 'ប្រភេទ' : 'Side'}</th>
                  <th className="py-2 px-3">{isKhmer ? 'តម្លៃចូល (Entry)' : 'Entry Price'}</th>
                  <th className="py-2 px-3">{isKhmer ? 'តម្លៃបច្ចុប្បន្ន' : 'Current Price'}</th>
                  <th className="py-2 px-3 text-rose-400">{isKhmer ? 'កាត់ខាត (SL)' : 'Stop Loss'}</th>
                  <th className="py-2 px-3 text-emerald-400">{isKhmer ? 'ចំណេញ (TP)' : 'Take Profit'}</th>
                  <th className="py-2 px-3">{isKhmer ? 'ទំហំ (Units)' : 'Size'}</th>
                  <th className="py-2 px-3">{isKhmer ? 'ចំណេញបណ្ដោះអាសន្ន' : 'Unrealized P&L'}</th>
                  <th className="py-2 px-3 text-right">{isKhmer ? 'សកម្មភាព' : 'Action'}</th>
                </tr>
              </thead>
              <tbody>
                {positions.map((pos) => {
                  const isProfit = pos.unrealizedPnl >= 0;
                  return (
                    <tr
                      key={pos.id}
                      className="border-b border-slate-800/60 hover:bg-slate-800/30 transition-colors"
                    >
                      <td className="py-2.5 px-3 font-bold text-slate-200">{pos.symbol}</td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`px-2 py-0.5 rounded font-bold ${
                            pos.type === 'BUY'
                              ? 'bg-teal-950 text-teal-300 border border-teal-800'
                              : 'bg-rose-950 text-rose-300 border border-rose-800'
                          }`}
                        >
                          {pos.type}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-300">${pos.entryPrice.toFixed(2)}</td>
                      <td className="py-2.5 px-3 text-slate-100">${pos.currentPrice.toFixed(2)}</td>
                      <td className="py-2.5 px-3 text-rose-400 font-semibold">${pos.slPrice.toFixed(2)}</td>
                      <td className="py-2.5 px-3 text-emerald-400 font-semibold">${pos.tpPrice.toFixed(2)}</td>
                      <td className="py-2.5 px-3 text-slate-300">{pos.sizeUnits}</td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`font-bold ${
                            isProfit ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {isProfit ? '+' : ''}
                          ${pos.unrealizedPnl.toFixed(2)} ({isProfit ? '+' : ''}
                          {pos.unrealizedPnlPercent}%)
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <button
                          onClick={() => botEngine.closePosition(pos, pos.currentPrice, 'MANUAL_CLOSE')}
                          className="px-2.5 py-1 bg-slate-800 hover:bg-rose-900/60 hover:text-rose-200 text-slate-300 rounded border border-slate-700 transition-colors text-[11px]"
                        >
                          {isKhmer ? 'បិទបញ្ជា' : 'Close'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Two Column Grid: Bot Settings & Webhook Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bot Parameters & Risk Management */}
        <div className="flex flex-col p-4 bg-[#0d121c] border border-slate-800 rounded-lg">
          <div className="flex items-center gap-2 mb-4">
            <ShieldCheck className="w-4 h-4 text-teal-400" />
            <h3 className="text-sm font-semibold text-slate-100">
              {isKhmer ? 'ការកំណត់ហានិភ័យ និង Bot (Bot Settings)' : 'Risk & Bot Settings'}
            </h3>
          </div>

          <div className="flex flex-col gap-4 text-xs">
            {/* Risk Per Trade */}
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium text-slate-200">
                  {isKhmer ? 'ហានិភ័យក្នុងមួយបញ្ជា (%)' : 'Risk Per Trade (%)'}
                </div>
                <div className="text-[11px] text-slate-400">
                  {isKhmer
                    ? 'គណនាទំហំ Lot/Unit ដោយស្វ័យប្រវត្តិតាមចម្ងាយ SL'
                    : 'Auto-calculates position size based on SL distance'}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="0.5"
                  max="10"
                  step="0.5"
                  value={config.riskPerTradePercent}
                  onChange={(e) =>
                    botEngine.updateConfig({
                      riskPerTradePercent: parseFloat(e.target.value) || 2.0,
                    })
                  }
                  className="w-16 px-2 py-1 bg-slate-900 border border-slate-700 rounded text-slate-100 text-right font-mono"
                />
                <span className="text-slate-400">%</span>
              </div>
            </div>

            {/* Max Leverage */}
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium text-slate-200">
                  {isKhmer ? 'កម្រិត Leverage' : 'Leverage Multiplier'}
                </div>
                <div className="text-[11px] text-slate-400">
                  {isKhmer ? 'សម្រាប់ Future / Margin' : 'For Margin & Futures trading'}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <select
                  value={config.maxLeverage}
                  onChange={(e) =>
                    botEngine.updateConfig({ maxLeverage: parseInt(e.target.value, 10) || 5 })
                  }
                  className="px-2 py-1 bg-slate-900 border border-slate-700 rounded text-slate-100 font-mono"
                >
                  <option value={1}>1x (Spot)</option>
                  <option value={2}>2x</option>
                  <option value={3}>3x</option>
                  <option value={5}>5x</option>
                  <option value={10}>10x</option>
                  <option value={20}>20x</option>
                </select>
              </div>
            </div>

            {/* Auto Close on Opposite */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
              <div>
                <div className="font-medium text-slate-200">
                  {isKhmer ? 'បិទបញ្ជាចាស់ពេលសញ្ញាផ្ទុយចេញ' : 'Auto-Close on Opposite Signal'}
                </div>
                <div className="text-[11px] text-slate-400">
                  {isKhmer ? 'បិទ BUY ភ្លាមៗបើមាន SELL ចេញ' : 'Closes active BUY if SELL appears'}
                </div>
              </div>
              <input
                type="checkbox"
                checked={config.autoCloseOnOpposite}
                onChange={(e) =>
                  botEngine.updateConfig({ autoCloseOnOpposite: e.target.checked })
                }
                className="w-4 h-4 rounded text-teal-600 bg-slate-900 border-slate-700 cursor-pointer accent-teal-500"
              />
            </div>

            {/* Trailing Stop Break-even */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
              <div>
                <div className="font-medium text-slate-200">
                  {isKhmer ? 'រំកិល SL មកស្មើតម្លៃដើម (Break-even at +1R)' : 'Trailing Break-even (+1R)'}
                </div>
                <div className="text-[11px] text-slate-400">
                  {isKhmer
                    ? 'ការពារដើមទុនពេលចំណេញបានពាក់កណ្ដាលផ្លូវ'
                    : 'Protects capital by shifting SL to Entry at +1R profit'}
                </div>
              </div>
              <input
                type="checkbox"
                checked={config.trailingStop}
                onChange={(e) => botEngine.updateConfig({ trailingStop: e.target.checked })}
                className="w-4 h-4 rounded text-teal-600 bg-slate-900 border-slate-700 cursor-pointer accent-teal-500"
              />
            </div>

            {/* Sound Alerts */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
              <div>
                <div className="font-medium text-slate-200">
                  {isKhmer ? 'សំឡេងជូនដំណឹង (Audio Sound)' : 'Sound Alerts'}
                </div>
                <div className="text-[11px] text-slate-400">
                  {isKhmer ? 'បន្លឺសំឡេងពេលចូលបញ្ជា និង TP/SL' : 'Plays chimes on Buy/Sell/TP/SL'}
                </div>
              </div>
              <input
                type="checkbox"
                checked={config.soundAlerts}
                onChange={(e) => botEngine.updateConfig({ soundAlerts: e.target.checked })}
                className="w-4 h-4 rounded text-teal-600 bg-slate-900 border-slate-700 cursor-pointer accent-teal-500"
              />
            </div>
          </div>
        </div>

        {/* Webhook Configuration & Manual Signal Tester */}
        <div className="flex flex-col p-4 bg-[#0d121c] border border-slate-800 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Send className="w-4 h-4 text-teal-400" />
              <h3 className="text-sm font-semibold text-slate-100">
                {isKhmer ? 'ការតភ្ជាប់ Webhook TradingView' : 'TradingView Webhook Setup'}
              </h3>
            </div>
          </div>

          <div className="flex flex-col gap-3 text-xs">
            <div>
              <span className="text-slate-400 text-[11px]">
                {isKhmer ? 'លេខកូដសម្ងាត់ Webhook Secret Key:' : 'Webhook Secret Key:'}
              </span>
              <div className="flex items-center gap-2 mt-1">
                <input
                  type="text"
                  readOnly
                  value={config.webhookSecret}
                  className="flex-1 px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded text-slate-200 font-mono text-[11px]"
                />
                <button
                  onClick={() => handleCopy(config.webhookSecret, 'secret')}
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 transition-colors"
                  title="Copy Secret"
                >
                  {copiedKey === 'secret' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* TradingView Alert Message JSON */}
            <div>
              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                <span>{isKhmer ? 'កូដសារ Webhook (Alert Message JSON):' : 'TradingView Alert Message Payload:'}</span>
                <button
                  onClick={() => handleCopy(webhookJsonExample, 'payload')}
                  className="text-teal-400 hover:underline flex items-center gap-1"
                >
                  {copiedKey === 'payload' ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-400" />
                      {isKhmer ? 'បានចម្លង' : 'Copied'}
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      {isKhmer ? 'ចម្លង' : 'Copy'}
                    </>
                  )}
                </button>
              </div>
              <pre className="p-2.5 bg-[#080c14] border border-slate-800 rounded font-mono text-[11px] text-teal-300 overflow-x-auto max-h-24">
                {webhookJsonExample}
              </pre>
            </div>

            {/* Live Webhook Tester Button */}
            <div className="pt-2 border-t border-slate-800">
              <span className="text-[11px] font-semibold text-slate-300 block mb-2">
                {isKhmer ? 'សាកល្បងផ្ញើសញ្ញាភ្លាមៗ (Test Signal):' : 'Simulate Incoming Webhook Signal:'}
              </span>
              <div className="flex items-center gap-2">
                <select
                  value={testAction}
                  onChange={(e) => setTestAction(e.target.value as 'BUY' | 'SELL')}
                  className={`px-3 py-1.5 rounded font-bold font-mono text-xs ${
                    testAction === 'BUY'
                      ? 'bg-teal-950 text-teal-300 border border-teal-800'
                      : 'bg-rose-950 text-rose-300 border border-rose-800'
                  }`}
                >
                  <option value="BUY">BUY Signal</option>
                  <option value="SELL">SELL Signal</option>
                </select>

                <input
                  type="number"
                  value={testPrice}
                  onChange={(e) => setTestPrice(parseFloat(e.target.value) || currentPrice)}
                  className="w-28 px-2 py-1.5 bg-slate-900 border border-slate-700 rounded text-slate-100 font-mono text-xs"
                  placeholder="Price"
                />

                <button
                  onClick={handleManualTestSignal}
                  className="flex-1 flex items-center justify-center gap-1.5 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded font-medium text-xs transition-colors"
                >
                  <Zap className="w-3.5 h-3.5" />
                  {isKhmer ? 'ដំណើរការសាកល្បង' : 'Execute Test'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Code Scripts Export (Python & Node.js for VPS deployment) */}
      <div className="flex flex-col p-4 bg-[#0d121c] border border-slate-800 rounded-lg">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Code className="w-4 h-4 text-teal-400" />
            <h3 className="text-sm font-semibold text-slate-100">
              {isKhmer
                ? 'កូដ Bot សម្រាប់ដាក់លើ Server / VPS (Python & Node.js Scripts)'
                : 'Production VPS Deployment Scripts (Binance / Bybit Auto Bot)'}
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center p-0.5 bg-slate-900 border border-slate-800 rounded">
              <button
                onClick={() => setActiveCodeTab('python')}
                className={`px-2.5 py-1 text-xs rounded transition-colors ${
                  activeCodeTab === 'python'
                    ? 'bg-teal-700 text-white font-medium'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Python (FastAPI + CCXT)
              </button>
              <button
                onClick={() => setActiveCodeTab('nodejs')}
                className={`px-2.5 py-1 text-xs rounded transition-colors ${
                  activeCodeTab === 'nodejs'
                    ? 'bg-teal-700 text-white font-medium'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Node.js (Express + CCXT)
              </button>
            </div>

            <button
              onClick={() =>
                handleCopy(
                  activeCodeTab === 'python' ? pythonBotScript : nodeJsBotScript,
                  'script'
                )
              }
              className="flex items-center gap-1 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded border border-slate-700 transition-colors"
            >
              {copiedKey === 'script' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  {isKhmer ? 'បានចម្លងកូដ' : 'Code Copied'}
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  {isKhmer ? 'ចម្លងកូដស្គ្រីប' : 'Copy Script'}
                </>
              )}
            </button>
          </div>
        </div>

        <pre className="p-4 bg-[#080c14] border border-slate-800 rounded font-mono text-[11px] text-slate-300 overflow-x-auto max-h-72 leading-relaxed">
          {activeCodeTab === 'python' ? pythonBotScript : nodeJsBotScript}
        </pre>
      </div>

      {/* Live Order & Execution Event Log */}
      <div className="flex flex-col p-4 bg-[#0d121c] border border-slate-800 rounded-lg">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-teal-400" />
            <h3 className="text-sm font-semibold text-slate-100">
              {isKhmer
                ? 'កំណត់ហេតុដំណើរការបញ្ជាទិញផ្ទាល់ (Live Execution Logs)'
                : 'Live Execution Logs'}
            </h3>
          </div>
          <span className="text-xs text-slate-400">
            {logs.length} {isKhmer ? 'ព្រឹត្តិការណ៍' : 'events'}
          </span>
        </div>

        <div className="flex flex-col gap-2 max-h-60 overflow-y-auto font-mono text-xs pr-1">
          {logs.map((log) => {
            const timeStr = new Date(log.time).toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
              second: '2-digit',
            });
            const isTp = log.type === 'TP_HIT';
            const isSl = log.type === 'SL_HIT';
            const isOrder = log.type === 'ORDER_OPEN';
            const isErr = log.type === 'ERROR';

            return (
              <div
                key={log.id}
                className={`p-2 rounded border flex items-start gap-2.5 ${
                  isTp
                    ? 'bg-emerald-950/40 border-emerald-800 text-emerald-200'
                    : isSl
                      ? 'bg-rose-950/40 border-rose-800 text-rose-200'
                      : isOrder
                        ? 'bg-teal-950/40 border-teal-800 text-teal-200'
                        : isErr
                          ? 'bg-red-950/40 border-red-800 text-red-200'
                          : 'bg-[#101622] border-slate-800/80 text-slate-300'
                }`}
              >
                <span className="text-slate-400 text-[11px] shrink-0">{timeStr}</span>
                <span className="font-semibold shrink-0 text-[11px]">[{log.type}]</span>
                <span className="flex-1 text-[11px]">
                  {isKhmer ? log.messageKh || log.message : log.message}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
