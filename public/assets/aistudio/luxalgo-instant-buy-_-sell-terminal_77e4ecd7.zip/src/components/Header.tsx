/**
 * Application Top Bar & Navigation Header
 * Complies strictly with the 3-Zone Top Bar Contract
 */

import React from 'react';
import { ActiveTab, Language, BotStatus } from '../types/trading';
import { Bot, Play, Pause, Globe } from 'lucide-react';

interface HeaderProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  botStatus: BotStatus;
  onToggleBot: () => void;
  lang: Language;
  onToggleLang: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  botStatus,
  onToggleBot,
  lang,
  onToggleLang,
}) => {
  const isKhmer = lang === 'km';

  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 bg-[#090d14] border-b border-slate-800 select-none">
      {/* Zone 1: Brand Wordmark (Single text element wordmark) */}
      <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
        <div className="p-1.5 bg-gradient-to-br from-teal-500 to-cyan-700 rounded-lg text-white shadow-sm">
          <Bot className="w-5 h-5" />
        </div>
        <span className="text-base font-bold tracking-tight text-slate-100 font-mono">
          LuxAlgo AutoBot <span className="text-teal-400 font-semibold">[ចេញភ្លាមៗ]</span>
        </span>
      </div>

      {/* Zone 2: 4-5 Clean single-line text navigation links */}
      <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
        <button
          onClick={() => onSelectTab('bot')}
          className={`whitespace-nowrap shrink-0 pb-0.5 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'bot'
              ? 'text-teal-400 border-teal-500 font-semibold'
              : 'text-slate-400 border-transparent hover:text-slate-200'
          }`}
        >
          {isKhmer ? 'ផ្ទាំងគ្រប់គ្រង Bot' : 'Bot Engine'}
        </button>

        <button
          onClick={() => onSelectTab('chart')}
          className={`whitespace-nowrap shrink-0 pb-0.5 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'chart'
              ? 'text-teal-400 border-teal-500 font-semibold'
              : 'text-slate-400 border-transparent hover:text-slate-200'
          }`}
        >
          {isKhmer ? 'ក្រាហ្វិកជួញដូរ' : 'Trading Chart'}
        </button>

        <button
          onClick={() => onSelectTab('backtest')}
          className={`whitespace-nowrap shrink-0 pb-0.5 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'backtest'
              ? 'text-teal-400 border-teal-500 font-semibold'
              : 'text-slate-400 border-transparent hover:text-slate-200'
          }`}
        >
          {isKhmer ? 'ការវាយតម្លៃ Backtest' : 'Backtest Report'}
        </button>

        <button
          onClick={() => onSelectTab('script')}
          className={`whitespace-nowrap shrink-0 pb-0.5 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'script'
              ? 'text-teal-400 border-teal-500 font-semibold'
              : 'text-slate-400 border-transparent hover:text-slate-200'
          }`}
        >
          {isKhmer ? 'កូដ Pine Script' : 'Pine Script v5'}
        </button>

        <button
          onClick={() => onSelectTab('alerts')}
          className={`whitespace-nowrap shrink-0 pb-0.5 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'alerts'
              ? 'text-teal-400 border-teal-500 font-semibold'
              : 'text-slate-400 border-transparent hover:text-slate-200'
          }`}
        >
          {isKhmer ? 'ការជូនដំណឹង' : 'Signal Alerts'}
        </button>
      </nav>

      {/* Zone 3: 1 Primary Action + Quick Language Toggle */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onToggleLang}
          className="flex items-center gap-1 px-2.5 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700/80 rounded border border-slate-700 transition-colors whitespace-nowrap shrink-0"
          title="Switch Language (Khmer / English)"
        >
          <Globe className="w-3.5 h-3.5 text-teal-400" />
          <span className="font-semibold">{isKhmer ? 'EN' : 'ខ្មែរ'}</span>
        </button>

        <button
          onClick={onToggleBot}
          className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white transition-colors whitespace-nowrap shrink-0 shadow-sm ${
            botStatus === 'RUNNING'
              ? 'bg-rose-600 hover:bg-rose-500'
              : 'bg-teal-600 hover:bg-teal-500'
          }`}
        >
          {botStatus === 'RUNNING' ? (
            <>
              <Pause className="w-3.5 h-3.5" />
              <span>{isKhmer ? 'ផ្អាក Bot' : 'Pause Bot'}</span>
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5" />
              <span>{isKhmer ? 'ដំណើរការ Bot' : 'Start Bot'}</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
};
