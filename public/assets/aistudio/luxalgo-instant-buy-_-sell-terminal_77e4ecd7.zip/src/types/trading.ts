/**
 * Types for LuxAlgo Pivot Based Buy & Sell with SL/TP [Instant / ចេញភ្លាមៗ]
 * and Auto Trading Bot Engine
 */

export type SignalMode =
  | 'Fast Pivot (ចេញលឿន 1-Bar)'
  | 'Instant Breakout (ចេញភ្លាមៗ 0-Bar)'
  | 'Classic LuxAlgo (ដើម 24-Bar)';

export interface IndicatorSettings {
  signalMode: SignalMode;
  leftBars: number;
  rightBars: number;
  rrRatio: number;
  backpaint: boolean;
  maxCss: string;
  minCss: string;
  avgCss: string;
  bullFill: string;
  bearFill: string;
}

export interface Candle {
  time: number; // Unix timestamp in ms
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface IndicatorBarData {
  ph: number | null;
  pl: number | null;
  max: number;
  min: number;
  avg: number;
  trend: 'bull' | 'bear';
  isBuy: boolean;
  isSell: boolean;
  entryPrice?: number;
  slPrice?: number;
  tpPrice?: number;
}

export type TradeStatus = 'WIN' | 'LOSS' | 'OPEN';

export interface Trade {
  id: string;
  type: 'BUY' | 'SELL';
  entryIndex: number;
  entryTime: number;
  entryPrice: number;
  slPrice: number;
  tpPrice: number;
  exitIndex?: number;
  exitTime?: number;
  exitPrice?: number;
  status: TradeStatus;
  rMultiple: number; // e.g. +2.0 or -1.0 or current floating R
  pnlPercent: number;
  pnlUsd?: number;
  durationBars: number;
}

export interface BacktestMetrics {
  totalTrades: number;
  winCount: number;
  lossCount: number;
  openCount: number;
  winRate: number; // Percentage 0 - 100
  profitFactor: number;
  netR: number; // Total R profit
  avgR: number;
  maxDrawdownR: number;
  bestTradeR: number;
  worstTradeR: number;
  equityCurve: { tradeIndex: number; cumulativeR: number }[];
}

export interface TradeAlert {
  id: string;
  time: number;
  symbol: string;
  timeframe: string;
  type: 'BUY' | 'SELL';
  entryPrice: number;
  slPrice: number;
  tpPrice: number;
  signalMode: SignalMode;
  read: boolean;
}

// Bot Specific Configurations and States
export type BotStatus = 'RUNNING' | 'PAUSED' | 'STOPPED';

export interface BotConfig {
  botEnabled: boolean;
  status: BotStatus;
  mode: 'PAPER' | 'WEBHOOK_SIM';
  initialBalance: number;
  currentBalance: number;
  riskPerTradePercent: number; // e.g., 2%
  maxLeverage: number; // 1x to 20x
  autoCloseOnOpposite: boolean; // Close BUY when SELL triggers
  trailingStop: boolean; // Move SL to break-even once +1R reached
  soundAlerts: boolean;
  webhookSecret: string;
  telegramChatId: string;
  telegramBotToken: string;
}

export interface BotPosition {
  id: string;
  symbol: string;
  type: 'BUY' | 'SELL';
  entryPrice: number;
  currentPrice: number;
  slPrice: number;
  tpPrice: number;
  sizeUnits: number;
  allocatedMargin: number;
  unrealizedPnl: number;
  unrealizedPnlPercent: number;
  entryTime: number;
  status: 'OPEN' | 'CLOSED';
  closedReason?: 'TAKE_PROFIT' | 'STOP_LOSS' | 'OPPOSITE_SIGNAL' | 'MANUAL_CLOSE';
  exitPrice?: number;
  exitTime?: number;
  realizedPnl?: number;
}

export interface BotLogItem {
  id: string;
  time: number;
  type: 'ORDER_OPEN' | 'ORDER_CLOSE' | 'WEBHOOK_RECEIVED' | 'TP_HIT' | 'SL_HIT' | 'INFO' | 'ERROR';
  message: string;
  messageKh: string;
  details?: Record<string, any>;
}

export type ActiveTab = 'chart' | 'bot' | 'backtest' | 'script' | 'alerts' | 'webhook_docs';
export type Language = 'km' | 'en'; // Khmer or English
