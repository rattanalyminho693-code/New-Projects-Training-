/**
 * Pine Script v5 Code Viewer and TradingView Setup Guide
 */

import React, { useState } from 'react';
import { Copy, Check, FileCode2, BookOpen, ExternalLink, Zap } from 'lucide-react';
import { Language } from '../types/trading';

interface PineScriptViewerProps {
  lang: Language;
}

export const PineScriptViewer: React.FC<PineScriptViewerProps> = ({ lang }) => {
  const isKhmer = lang === 'km';
  const [copied, setCopied] = useState(false);

  const pineScriptCode = `// This work is licensed under a Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0) https://creativecommons.org/licenses/by-nc-sa/4.0/
// © LuxAlgo & Modified [Instant / ចេញភ្លាមៗ]

//@version=5
indicator("Pivot Based Buy & Sell with SL/TP [Instant / ចេញភ្លាមៗ]", "LuxAlgo - Buy/Sell SL & TP [Instant]", overlay = true, max_bars_back = 500, max_lines_count = 500)

//------------------------------------------------------------------------------
//Settings / ការកំណត់ល្បឿនសញ្ញា
//-----------------------------------------------------------------------------{
signal_mode = input.string("Fast Pivot (ចេញលឿន 1-Bar)", "Signal Mode / ប្រភេទសញ្ញា", options=["Fast Pivot (ចេញលឿន 1-Bar)", "Instant Breakout (ចេញភ្លាមៗ 0-Bar)", "Classic LuxAlgo (ដើម 24-Bar)"])
left_bars   = input.int(12, minval = 2, maxval = 500, title="Pivot Left Bars (ស្វែងរកកម្រិតទាប/ខ្ពស់)")
right_bars  = input.int(1, minval = 1, maxval = 50, title="Pivot Right Bars (1 = ចេញភ្លាមៗបន្ទាប់ពី 1 ទាន)")
rr_ratio    = input.float(2.0, title="Risk-Reward Ratio (TP multiplier)", minval=0.1)
backpaint   = input(false, tooltip = 'Backpainting offset displayed elements in the past.')

//Style
maxCss = input.color(color.teal, 'Trailing Maximum Color', group = 'Style')
minCss = input.color(color.red , 'Trailing Minimum Color', group = 'Style')
avgCss = input.color(#ff5d00   , 'Trailing Average Color', group = 'Style')

bullFill = input.color(color.new(color.teal,80), 'Uptrend Area', group = 'Style')
bearFill = input.color(color.new(color.red,80) , 'Downtrend Area', group = 'Style')

//-----------------------------------------------------------------------------}
//Calculation
//-----------------------------------------------------------------------------{
var float max = na
var float min = na

effective_right = signal_mode == "Classic LuxAlgo (ដើម 24-Bar)" ? left_bars : right_bars
offset = backpaint ? left_bars : 0

ph = ta.pivothigh(left_bars, effective_right)
pl = ta.pivotlow(left_bars, effective_right)

if ph or pl
    max := high[effective_right]
    min := low[effective_right]

max := math.max(high[offset], max)
min := math.min(low[offset], min)

avg = math.avg(max, min)

//-----------------------------------------------------------------------------}
//Buy & Sell Signals (ចេញភ្លាមៗ)
//-----------------------------------------------------------------------------{
// 1. Pivot Trigger: ពេល right_bars = 1 សញ្ញាចេញភ្លាមៗនៅពេលទានបន្ទាប់បិទ (1-Bar Delay)
is_buy_pivot  = not na(pl)
is_sell_pivot = not na(ph)

// 2. Breakout Trigger: ចេញភ្លាមៗពេលតម្លៃទម្លុះ Trailing Channel (0-Bar Delay)
is_buy_break  = ta.crossover(close, max[1])
is_sell_break = ta.crossunder(close, min[1])

is_buy  = signal_mode == "Instant Breakout (ចេញភ្លាមៗ 0-Bar)" ? is_buy_break  : is_buy_pivot
is_sell = signal_mode == "Instant Breakout (ចេញភ្លាមៗ 0-Bar)" ? is_sell_break : is_sell_pivot

var float entry_price = na
var float sl_price = na
var float tp_price = na

if is_buy
    entry_price := close
    sl_price := signal_mode == "Instant Breakout (ចេញភ្លាមៗ 0-Bar)" ? ta.lowest(low, 5) : low[effective_right]
    if sl_price >= entry_price
        sl_price := entry_price * 0.99
    tp_price := entry_price + (entry_price - sl_price) * rr_ratio
    label.new(bar_index - offset, low, text="BUY\\nEntry: " + str.tostring(entry_price, "#.##") + "\\nSL: " + str.tostring(sl_price, "#.##") + "\\nTP: " + str.tostring(tp_price, "#.##"), color=color.teal, textcolor=color.white, style=label.style_label_up, size=size.small)

if is_sell
    entry_price := close
    sl_price := signal_mode == "Instant Breakout (ចេញភ្លាមៗ 0-Bar)" ? ta.highest(high, 5) : high[effective_right]
    if sl_price <= entry_price
        sl_price := entry_price * 1.01
    tp_price := entry_price - (sl_price - entry_price) * rr_ratio
    label.new(bar_index - offset, high, text="SELL\\nEntry: " + str.tostring(entry_price, "#.##") + "\\nSL: " + str.tostring(sl_price, "#.##") + "\\nTP: " + str.tostring(tp_price, "#.##"), color=color.red, textcolor=color.white, style=label.style_label_down, size=size.small)

// Alert Conditions សម្រាប់ TradingView (ជូនដំណឹងលឿនបំផុត)
alertcondition(is_buy, title="BUY Alert [ចេញភ្លាមៗ]", message="LuxAlgo BUY Signal! Entry: {{close}}")
alertcondition(is_sell, title="SELL Alert [ចេញភ្លាមៗ]", message="LuxAlgo SELL Signal! Entry: {{close}}")

//-----------------------------------------------------------------------------}
//Non offset trailing max/min
//-----------------------------------------------------------------------------{
n = bar_index

max_prev = max
min_prev = min
avg_prev = avg
max2 = max
min2 = min

fill_css = fixnan(ph ? bearFill : pl ? bullFill : na)

if barstate.islast and backpaint
    for line_object in line.all
        line.delete(line_object)

    for i = 0 to left_bars-1
        max2 := math.max(high[left_bars-1-i], max_prev)
        min2 := math.min(low[left_bars-1-i], min_prev)
        avg2 = math.avg(max2, min2)
        
        line1 = line.new(n-(left_bars-i), max_prev, n-(left_bars-1-i), max2, color= maxCss)
        line2 = line.new(n-(left_bars-i), min_prev, n-(left_bars-1-i), min2, color= minCss)
        linefill.new(line1,line2,color.new(fill_css, 80))

        line.new(n-(left_bars-i), avg_prev, n-(left_bars-1-i), avg2, color= avgCss)
        
        max_prev := max2
        min_prev := min2
        avg_prev := avg2

//-----------------------------------------------------------------------------}
//Plots
//-----------------------------------------------------------------------------{
plot1 = plot(max, 'Trailing Maximum', ph or pl ? na : maxCss, 1, plot.style_linebr, offset = -offset)
plot2 = plot(min, 'Trailing Minimum', ph or pl ? na : minCss, 1, plot.style_linebr, offset = -offset)
plot(avg, 'Average', ph or pl ? na : avgCss, 1, plot.style_linebr, offset = -offset)

fill(plot1, plot2, ph or pl ? na : fill_css)
`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(pineScriptCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col gap-6 text-slate-200">
      {/* Explanation Banner */}
      <div className="p-4 bg-[#0d121c] border border-slate-800 rounded-lg">
        <div className="flex items-center gap-2 mb-2">
          <BookOpen className="w-4 h-4 text-teal-400" />
          <h3 className="text-sm font-semibold text-slate-100">
            {isKhmer
              ? 'ការណែនាំដំឡើងលើ TradingView និងភ្ជាប់ Bot Auto Trading'
              : 'TradingView Installation & Auto Bot Integration Guide'}
          </h3>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed mb-4">
          {isKhmer
            ? 'កូដ Pine Script នេះជាកូដដើមរបស់ LuxAlgo ដែលត្រូវបានកែសម្រួលដើម្បីឱ្យសញ្ញា BUY និង SELL ចេញភ្លាមៗ (ចេញលឿន 1-Bar ឬ 0-Bar Delay) ព្រមទាំងគណនាកម្រិតកាត់ខាត (SL) និងយកចំណេញ (TP) ដោយស្វ័យប្រវត្តិ។ អ្នកអាចយកកូដនេះទៅដាក់ក្នុង TradingView ហើយភ្ជាប់ Webhook ជាមួយ Bot របស់យើង ដើម្បីធ្វើការជួញដូរស្វ័យប្រវត្តិបាន!'
            : 'This modified Pine Script v5 indicator provides instant buy & sell signals with calculated Stop Loss and Take Profit levels. By setting right_bars to 1, signals are confirmed with zero repainting after just 1 candle close, or 0-bar on channel breakout!'}
        </p>

        {/* 3 Steps */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="p-3 bg-[#111724] border border-slate-800/80 rounded">
            <span className="text-[11px] font-bold text-teal-400">
              {isKhmer ? 'ជំហានទី 1: ចម្លងកូដ' : 'Step 1: Copy Code'}
            </span>
            <p className="text-[11px] text-slate-300 mt-1">
              {isKhmer
                ? 'ចុចប៊ូតុង "ចម្លងកូដ Pine Script" នៅខាងក្រោម រួចបើក TradingView.'
                : 'Click "Copy Pine Script" below, then open your TradingView chart.'}
            </p>
          </div>
          <div className="p-3 bg-[#111724] border border-slate-800/80 rounded">
            <span className="text-[11px] font-bold text-teal-400">
              {isKhmer ? 'ជំហានទី 2: ដាក់លើ Pine Editor' : 'Step 2: Add to Pine Editor'}
            </span>
            <p className="text-[11px] text-slate-300 mt-1">
              {isKhmer
                ? 'បើកផ្ទាំង Pine Editor លើ TradingView -> Paste កូដចូល -> ចុច "Add to chart".'
                : 'Open Pine Editor tab at the bottom of TradingView -> Paste -> Click "Add to chart".'}
            </p>
          </div>
          <div className="p-3 bg-[#111724] border border-slate-800/80 rounded">
            <span className="text-[11px] font-bold text-teal-400">
              {isKhmer ? 'ជំហានទី 3: បង្កើត Alert Webhook' : 'Step 3: Create Alert Webhook'}
            </span>
            <p className="text-[11px] text-slate-300 mt-1">
              {isKhmer
                ? 'ចុច Create Alert លើ Indicator -> ជ្រើសរើស Webhook URL -> ដាក់កូដសារ JSON ពីផ្ទាំង Bot របស់យើង!'
                : 'Click Create Alert on indicator -> Check Webhook URL -> Paste JSON message to auto-execute!'}
            </p>
          </div>
        </div>
      </div>

      {/* Code Editor Frame */}
      <div className="flex flex-col bg-[#0d121c] border border-slate-800 rounded-lg overflow-hidden">
        {/* Code Toolbar */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-[#090d14] border-b border-slate-800">
          <div className="flex items-center gap-2">
            <FileCode2 className="w-4 h-4 text-teal-400" />
            <span className="text-xs font-semibold text-slate-200">
              indicator("Pivot Based Buy &amp; Sell with SL/TP [Instant / ចេញភ្លាមៗ]", overlay = true)
            </span>
          </div>

          <button
            onClick={handleCopyCode}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded text-xs font-medium transition-colors"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>{isKhmer ? 'បានចម្លងរួចរាល់' : 'Code Copied!'}</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>{isKhmer ? 'ចម្លងកូដ Pine Script' : 'Copy Pine Script'}</span>
              </>
            )}
          </button>
        </div>

        {/* Code Block */}
        <pre className="p-4 bg-[#080c14] font-mono text-xs text-slate-300 overflow-x-auto max-h-[500px] leading-relaxed selection:bg-teal-500/30">
          {pineScriptCode}
        </pre>
      </div>
    </div>
  );
};
