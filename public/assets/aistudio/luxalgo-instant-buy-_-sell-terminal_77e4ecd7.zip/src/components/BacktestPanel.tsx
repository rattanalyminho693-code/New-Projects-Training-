/**
 * Quantitative Backtest Performance & Trade Log Panel
 */

import React, { useState } from 'react';
import { BacktestMetrics, Trade, Language } from '../types/trading';
import {
  TrendingUp,
  Award,
  BarChart3,
  Percent,
  Download,
  CheckCircle2,
  XCircle,
  Clock,
} from 'lucide-react';

interface BacktestPanelProps {
  metrics: BacktestMetrics;
  trades: Trade[];
  onSelectTrade: (index: number) => void;
  decimals?: number;
  symbol: string;
  lang: Language;
}

export const BacktestPanel: React.FC<BacktestPanelProps> = ({
  metrics,
  trades,
  onSelectTrade,
  decimals = 2,
  symbol,
  lang,
}) => {
  const isKhmer = lang === 'km';
  const [filter, setFilter] = useState<'ALL' | 'WIN' | 'LOSS' | 'OPEN'>('ALL');

  const filteredTrades = trades.filter((t) => {
    if (filter === 'ALL') return true;
    return t.status === filter;
  });

  const exportCsv = () => {
    const headers = [
      'ID',
      'Type',
      'Entry Time',
      'Entry Price',
      'Stop Loss',
      'Take Profit',
      'Exit Price',
      'Status',
      'R-Multiple',
      'Return %',
      'Duration (Bars)',
    ];
    const rows = trades.map((t) => [
      t.id,
      t.type,
      new Date(t.entryTime).toISOString(),
      t.entryPrice,
      t.slPrice,
      t.tpPrice,
      t.exitPrice || '',
      t.status,
      t.rMultiple,
      t.pnlPercent,
      t.durationBars,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `luxalgo_backtest_${symbol.replace('/', '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex flex-col gap-6 text-slate-200">
      {/* KPI Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {/* Win Rate */}
        <div className="p-3 bg-[#0d121c] border border-slate-800 rounded-md">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>{isKhmer ? 'អត្រាឈ្នះ (Win Rate)' : 'Win Rate'}</span>
            <Award className="w-3.5 h-3.5 text-teal-400" />
          </div>
          <div className="text-xl font-bold font-mono text-teal-400 mt-1">
            {metrics.winRate}%
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            {metrics.winCount}W / {metrics.lossCount}L
          </div>
        </div>

        {/* Profit Factor */}
        <div className="p-3 bg-[#0d121c] border border-slate-800 rounded-md">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>{isKhmer ? 'មេគុណចំណេញ' : 'Profit Factor'}</span>
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-xl font-bold font-mono text-emerald-400 mt-1">
            {metrics.profitFactor}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            {metrics.profitFactor >= 1.5 ? (isKhmer ? 'ល្អខ្លាំង' : 'Excellent') : (isKhmer ? 'មធ្យម' : 'Moderate')}
          </div>
        </div>

        {/* Total Return in R */}
        <div className="p-3 bg-[#0d121c] border border-slate-800 rounded-md">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>{isKhmer ? 'ផលចំណេញសុទ្ធ' : 'Net Profit'}</span>
            <Percent className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div
            className={`text-xl font-bold font-mono mt-1 ${
              metrics.netR >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {metrics.netR >= 0 ? '+' : ''}
            {metrics.netR} R
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5 font-mono">
            Avg: {metrics.avgR >= 0 ? '+' : ''}
            {metrics.avgR} R / trade
          </div>
        </div>

        {/* Max Drawdown */}
        <div className="p-3 bg-[#0d121c] border border-slate-800 rounded-md">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>{isKhmer ? 'ការខាតអតិបរមា' : 'Max Drawdown'}</span>
            <BarChart3 className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <div className="text-xl font-bold font-mono text-rose-400 mt-1">
            -{metrics.maxDrawdownR} R
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            {isKhmer ? 'កម្រិតសុវត្ថិភាពទុន' : 'Risk of Ruin metric'}
          </div>
        </div>

        {/* Total Trades */}
        <div className="p-3 bg-[#0d121c] border border-slate-800 rounded-md">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>{isKhmer ? 'ចំនួនសរុប' : 'Total Trades'}</span>
            <Clock className="w-3.5 h-3.5 text-slate-400" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-100 mt-1">
            {metrics.totalTrades}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            {metrics.openCount} {isKhmer ? 'កំពុងដំណើរការ' : 'open'}
          </div>
        </div>

        {/* Best / Worst Trade */}
        <div className="p-3 bg-[#0d121c] border border-slate-800 rounded-md">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>{isKhmer ? 'ល្អ / អន់បំផុត' : 'Best / Worst'}</span>
            <Award className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-sm font-bold font-mono text-slate-200 mt-1.5">
            <span className="text-emerald-400">+{metrics.bestTradeR}R</span> /{' '}
            <span className="text-rose-400">{metrics.worstTradeR}R</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            {isKhmer ? 'ទិន្នន័យជាក់ស្ដែង' : 'Historical R-dist'}
          </div>
        </div>
      </div>

      {/* Equity Curve SVG Mini Chart */}
      <div className="p-4 bg-[#0d121c] border border-slate-800 rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <div className="text-xs font-semibold text-slate-200">
            {isKhmer ? 'ក្រាហ្វិកកំណើនទុន (Cumulative R Equity Curve)' : 'Cumulative Equity Curve (R Multiples)'}
          </div>
          <div className="text-[11px] font-mono text-slate-400">
            {metrics.equityCurve.length - 1} {isKhmer ? 'បញ្ជាជួញដូរ' : 'trades evaluated'}
          </div>
        </div>

        {metrics.equityCurve.length > 1 ? (
          <div className="h-32 w-full pt-2">
            <svg className="w-full h-full overflow-visible" preserveAspectRatio="none">
              {(() => {
                const points = metrics.equityCurve;
                const rValues = points.map((p) => p.cumulativeR);
                const minVal = Math.min(0, ...rValues);
                const maxVal = Math.max(1, ...rValues);
                const range = maxVal - minVal || 1;

                const svgWidth = 1000;
                const svgHeight = 110;

                const getSvgX = (i: number) => (i / (points.length - 1)) * svgWidth;
                const getSvgY = (v: number) =>
                  svgHeight - ((v - minVal) / range) * (svgHeight - 16) - 8;

                const zeroY = getSvgY(0);

                const pathD = points
                  .map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${getSvgX(idx)} ${getSvgY(p.cumulativeR)}`)
                  .join(' ');

                const areaD = `${pathD} L ${svgWidth} ${zeroY} L 0 ${zeroY} Z`;

                return (
                  <>
                    <line
                      x1="0"
                      y1={zeroY}
                      x2={svgWidth}
                      y2={zeroY}
                      stroke="#334155"
                      strokeDasharray="4 4"
                      strokeWidth="1"
                    />
                    <path d={areaD} fill="rgba(20, 184, 166, 0.15)" />
                    <path d={pathD} fill="none" stroke="#14b8a6" strokeWidth="2.2" />
                  </>
                );
              })()}
            </svg>
          </div>
        ) : (
          <div className="p-8 text-center text-xs text-slate-500">
            {isKhmer ? 'មិនទាន់មានទិន្នន័យក្រាហ្វិកគ្រប់គ្រាន់' : 'Not enough trades to plot equity curve.'}
          </div>
        )}
      </div>

      {/* Trade Log Table */}
      <div className="flex flex-col p-4 bg-[#0d121c] border border-slate-800 rounded-lg">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-slate-100">
              {isKhmer ? 'ប្រវត្តិបញ្ជាជួញដូរលម្អិត (Trade History Log)' : 'Executed Signal & Trade Log'}
            </span>
            <span className="text-xs font-mono text-slate-400">({trades.length})</span>
          </div>

          <div className="flex items-center gap-2">
            {/* Filter Buttons */}
            <div className="flex items-center p-0.5 bg-slate-900 border border-slate-800 rounded text-xs">
              {(['ALL', 'WIN', 'LOSS', 'OPEN'] as const).map((st) => (
                <button
                  key={st}
                  onClick={() => setFilter(st)}
                  className={`px-2.5 py-1 rounded transition-colors ${
                    filter === st
                      ? 'bg-slate-800 text-teal-400 font-bold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {st === 'ALL'
                    ? isKhmer
                      ? 'ទាំងអស់'
                      : 'All'
                    : st === 'WIN'
                      ? isKhmer
                        ? 'ឈ្នះ (Wins)'
                        : 'Wins'
                      : st === 'LOSS'
                        ? isKhmer
                          ? 'ចាញ់ (Losses)'
                          : 'Losses'
                        : isKhmer
                          ? 'កំពុងរង់ចាំ'
                          : 'Pending'}
                </button>
              ))}
            </div>

            {/* Export CSV */}
            <button
              onClick={exportCsv}
              className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs border border-slate-700 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isKhmer ? 'ទាញយក CSV' : 'Export CSV'}</span>
            </button>
          </div>
        </div>

        {filteredTrades.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500 border border-slate-800/80 rounded bg-[#090d14]">
            {isKhmer ? 'មិនមានបញ្ជាជួញដូរត្រូវនឹងលក្ខខណ្ឌចម្រាញ់នេះទេ' : 'No trades found matching this filter.'}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2 px-3">{isKhmer ? 'ស្ថានភាព' : 'Status'}</th>
                  <th className="py-2 px-3">{isKhmer ? 'ប្រភេទ' : 'Side'}</th>
                  <th className="py-2 px-3">{isKhmer ? 'ពេលវេលា' : 'Entry Time'}</th>
                  <th className="py-2 px-3">{isKhmer ? 'តម្លៃចូល (Entry)' : 'Entry Price'}</th>
                  <th className="py-2 px-3 text-rose-400">{isKhmer ? 'កាត់ខាត (SL)' : 'Stop Loss'}</th>
                  <th className="py-2 px-3 text-emerald-400">{isKhmer ? 'យកចំណេញ (TP)' : 'Take Profit'}</th>
                  <th className="py-2 px-3">{isKhmer ? 'តម្លៃបិទ' : 'Exit Price'}</th>
                  <th className="py-2 px-3">{isKhmer ? 'លទ្ធផល R' : 'Outcome (R)'}</th>
                  <th className="py-2 px-3 text-right">{isKhmer ? 'សកម្មភាព' : 'Action'}</th>
                </tr>
              </thead>
              <tbody>
                {filteredTrades.map((t) => {
                  const isWin = t.status === 'WIN';
                  const isLoss = t.status === 'LOSS';
                  const dateStr = new Date(t.entryTime).toLocaleDateString([], {
                    month: 'short',
                    day: 'numeric',
                  });
                  const timeStr = new Date(t.entryTime).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  });

                  return (
                    <tr
                      key={t.id}
                      className="border-b border-slate-800/60 hover:bg-slate-800/30 transition-colors cursor-pointer"
                      onClick={() => onSelectTrade(t.entryIndex)}
                    >
                      <td className="py-2 px-3">
                        <div className="flex items-center gap-1.5">
                          {isWin ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          ) : isLoss ? (
                            <XCircle className="w-3.5 h-3.5 text-rose-400" />
                          ) : (
                            <Clock className="w-3.5 h-3.5 text-amber-400" />
                          )}
                          <span
                            className={`font-semibold ${
                              isWin
                                ? 'text-emerald-400'
                                : isLoss
                                  ? 'text-rose-400'
                                  : 'text-amber-400'
                            }`}
                          >
                            {t.status}
                          </span>
                        </div>
                      </td>
                      <td className="py-2 px-3">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[11px] font-bold ${
                            t.type === 'BUY'
                              ? 'bg-teal-950 text-teal-300 border border-teal-800'
                              : 'bg-rose-950 text-rose-300 border border-rose-800'
                          }`}
                        >
                          {t.type}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-slate-400">
                        {dateStr} {timeStr}
                      </td>
                      <td className="py-2 px-3 text-slate-200">${t.entryPrice.toFixed(decimals)}</td>
                      <td className="py-2 px-3 text-rose-400">${t.slPrice.toFixed(decimals)}</td>
                      <td className="py-2 px-3 text-emerald-400">${t.tpPrice.toFixed(decimals)}</td>
                      <td className="py-2 px-3 text-slate-300">
                        {t.exitPrice ? `$${t.exitPrice.toFixed(decimals)}` : '—'}
                      </td>
                      <td className="py-2 px-3 font-bold">
                        <span
                          className={
                            isWin
                              ? 'text-emerald-400'
                              : isLoss
                                ? 'text-rose-400'
                                : 'text-slate-300'
                          }
                        >
                          {t.rMultiple >= 0 ? '+' : ''}
                          {t.rMultiple} R ({t.pnlPercent >= 0 ? '+' : ''}
                          {t.pnlPercent}%)
                        </span>
                      </td>
                      <td className="py-2 px-3 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectTrade(t.entryIndex);
                          }}
                          className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-teal-300 rounded border border-slate-700 text-[10px]"
                        >
                          {isKhmer ? 'មើលក្រាហ្វិក' : 'View Chart'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
