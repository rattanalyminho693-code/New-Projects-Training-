/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  ActiveTab,
  IndicatorSettings,
  Language,
  TradeAlert,
  Candle,
} from './types/trading';
import {
  SUPPORTED_ASSETS,
  TIMEFRAMES,
  MarketAsset,
  fetchMarketCandles,
} from './services/marketData';
import {
  computeLuxAlgoIndicator,
  runIndicatorBacktest,
} from './services/pineIndicator';
import { botEngine } from './services/tradingBotEngine';
import { soundAlert } from './services/soundAlert';

import { Header } from './components/Header';
import { TradingChart } from './components/TradingChart';
import { AutoTradingBotPanel } from './components/AutoTradingBotPanel';
import { BacktestPanel } from './components/BacktestPanel';
import { PineScriptViewer } from './components/PineScriptViewer';
import { AlertsPanel } from './components/AlertsPanel';
import { SettingsModal } from './components/SettingsModal';

import {
  Sliders,
  Play,
  Pause,
  Zap,
  TrendingUp,
  TrendingDown,
  Layers,
  Sparkles,
} from 'lucide-react';

const DEFAULT_SETTINGS: IndicatorSettings = {
  signalMode: 'Fast Pivot (ចេញលឿន 1-Bar)',
  leftBars: 12,
  rightBars: 1,
  rrRatio: 2.0,
  backpaint: false,
  maxCss: '#14b8a6',
  minCss: '#ef4444',
  avgCss: '#ff5d00',
  bullFill: 'rgba(20, 184, 166, 0.15)',
  bearFill: 'rgba(239, 68, 68, 0.15)',
};

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('bot');
  const [lang, setLang] = useState<Language>('km'); // Default to Khmer as requested
  const isKhmer = lang === 'km';

  const [selectedAsset, setSelectedAsset] = useState<MarketAsset>(SUPPORTED_ASSETS[0]);
  const [timeframe, setTimeframe] = useState<string>('15m');
  const [settings, setSettings] = useState<IndicatorSettings>(DEFAULT_SETTINGS);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  // Candles data
  const [candles, setCandles] = useState<Candle[]>([]);
  const [isLoadingCandles, setIsLoadingCandles] = useState<boolean>(true);

  // Simulation & Real-time tick engine
  const [isSimulating, setIsSimulating] = useState<boolean>(true);
  const [simSpeed, setSimSpeed] = useState<number>(1000); // ms per tick

  // Selected trade for zooming in chart
  const [selectedTradeIndex, setSelectedTradeIndex] = useState<number | null>(null);

  // Alerts array
  const [alerts, setAlerts] = useState<TradeAlert[]>([]);

  // Bot Engine state subscription
  const [botState, setBotState] = useState(botEngine.state);
  useEffect(() => {
    return botEngine.subscribe(() => {
      setBotState({ ...botEngine.state });
    });
  }, []);

  // Fetch / Generate candles on asset or timeframe change
  useEffect(() => {
    let isMounted = true;
    setIsLoadingCandles(true);

    fetchMarketCandles(selectedAsset, timeframe, 180).then((data) => {
      if (!isMounted) return;
      setCandles(data);
      setIsLoadingCandles(false);
    });

    return () => {
      isMounted = false;
    };
  }, [selectedAsset, timeframe]);

  // Compute Indicator values
  const indicatorData = useMemo(() => {
    return computeLuxAlgoIndicator(candles, settings);
  }, [candles, settings]);

  // Compute Backtest metrics
  const backtestResult = useMemo(() => {
    return runIndicatorBacktest(candles, indicatorData, settings.rrRatio);
  }, [candles, indicatorData, settings.rrRatio]);

  // Real-time tick generator & Auto Trading signal detector
  useEffect(() => {
    if (!isSimulating || candles.length === 0) return;

    const interval = setInterval(() => {
      setCandles((prevCandles) => {
        if (prevCandles.length === 0) return prevCandles;

        const lastIdx = prevCandles.length - 1;
        const last = prevCandles[lastIdx];

        // Random micro fluctuation
        const volatility = selectedAsset.basePrice * 0.0006;
        const delta = (Math.random() - 0.495) * volatility;
        const newClose = Number(Math.max(last.low * 0.99, last.close + delta).toFixed(selectedAsset.decimals));
        const newHigh = Number(Math.max(last.high, newClose).toFixed(selectedAsset.decimals));
        const newLow = Number(Math.min(last.low, newClose).toFixed(selectedAsset.decimals));
        const newVolume = last.volume + Math.floor(Math.random() * 8 + 1);

        const updatedCandle: Candle = {
          ...last,
          close: newClose,
          high: newHigh,
          low: newLow,
          volume: newVolume,
        };

        // Notify bot engine with tick
        botEngine.processTick(selectedAsset.symbol, newClose);

        const updatedList = [...prevCandles];
        updatedList[lastIdx] = updatedCandle;
        return updatedList;
      });
    }, simSpeed);

    return () => clearInterval(interval);
  }, [isSimulating, simSpeed, selectedAsset, candles.length]);

  // Listen for newly confirmed buy/sell signals on latest bar
  const lastSignalProcessedRef = React.useRef<number>(-1);
  useEffect(() => {
    if (indicatorData.length === 0 || candles.length === 0) return;

    const lastIdx = indicatorData.length - 1;
    const latestBar = indicatorData[lastIdx];
    const latestCandle = candles[lastIdx];

    if (!latestBar || !latestCandle) return;

    if (
      (latestBar.isBuy || latestBar.isSell) &&
      lastSignalProcessedRef.current !== latestCandle.time
    ) {
      lastSignalProcessedRef.current = latestCandle.time;
      const type = latestBar.isBuy ? 'BUY' : 'SELL';
      const entryPrice = latestBar.entryPrice || latestCandle.close;
      const slPrice = latestBar.slPrice || (type === 'BUY' ? entryPrice * 0.985 : entryPrice * 1.015);
      const tpPrice =
        latestBar.tpPrice ||
        (type === 'BUY'
          ? entryPrice + (entryPrice - slPrice) * settings.rrRatio
          : entryPrice - (slPrice - entryPrice) * settings.rrRatio);

      // Execute in AutoBot
      botEngine.executeSignal(
        selectedAsset.symbol,
        type,
        entryPrice,
        slPrice,
        tpPrice,
        'INDICATOR'
      );

      // Add to alerts
      const newAlert: TradeAlert = {
        id: `alert_${Date.now()}_${Math.random()}`,
        time: Date.now(),
        symbol: selectedAsset.symbol,
        timeframe,
        type,
        entryPrice,
        slPrice,
        tpPrice,
        signalMode: settings.signalMode,
        read: false,
      };
      setAlerts((prev) => [newAlert, ...prev.slice(0, 49)]);
    }
  }, [indicatorData, candles, selectedAsset.symbol, timeframe, settings.signalMode, settings.rrRatio]);

  const latestCandle = candles[candles.length - 1];
  const firstCandle = candles[0];
  const priceChange =
    latestCandle && firstCandle
      ? latestCandle.close - firstCandle.open
      : 0;
  const priceChangePercent =
    latestCandle && firstCandle
      ? (priceChange / firstCandle.open) * 100
      : 0;

  const handleSelectTrade = useCallback((tradeIndex: number) => {
    setSelectedTradeIndex(tradeIndex);
    setActiveTab('chart');
  }, []);

  return (
    <div className="flex flex-col min-h-screen bg-[#080c14] text-slate-100 font-sans">
      {/* 3-Zone Standard Top Navigation */}
      <Header
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        botStatus={botState.config.status}
        onToggleBot={() => {
          const next = botState.config.status === 'RUNNING' ? 'PAUSED' : 'RUNNING';
          botEngine.updateConfig({
            status: next,
            botEnabled: next === 'RUNNING',
          });
        }}
        lang={lang}
        onToggleLang={() => setLang((prev) => (prev === 'km' ? 'en' : 'km'))}
      />

      {/* Sub-Header / Workspace Contextual Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-2.5 bg-[#0b1019] border-b border-slate-800 text-xs">
        {/* Left: Asset Picker & Price Display */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <select
              value={selectedAsset.symbol}
              onChange={(e) => {
                const found = SUPPORTED_ASSETS.find((a) => a.symbol === e.target.value);
                if (found) setSelectedAsset(found);
              }}
              className="px-2.5 py-1.5 bg-[#121927] border border-slate-700 rounded font-mono font-bold text-slate-100 text-xs cursor-pointer focus:outline-none focus:border-teal-500"
            >
              {SUPPORTED_ASSETS.map((asset) => (
                <option key={asset.symbol} value={asset.symbol}>
                  {asset.symbol} ({asset.name})
                </option>
              ))}
            </select>

            {/* Timeframe Buttons */}
            <div className="hidden sm:flex items-center p-0.5 bg-[#121927] border border-slate-800 rounded font-mono text-[11px]">
              {TIMEFRAMES.map((tf) => (
                <button
                  key={tf.id}
                  onClick={() => setTimeframe(tf.id)}
                  className={`px-2 py-1 rounded transition-colors ${
                    timeframe === tf.id
                      ? 'bg-teal-600 text-white font-bold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tf.label}
                </button>
              ))}
            </div>
          </div>

          {/* Current Live Price & 24h delta */}
          {latestCandle && (
            <div className="flex items-center gap-2.5 font-mono">
              <span className="text-sm font-bold text-slate-100">
                ${latestCandle.close.toFixed(selectedAsset.decimals)}
              </span>
              <span
                className={`flex items-center text-[11px] font-semibold ${
                  priceChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {priceChange >= 0 ? (
                  <TrendingUp className="w-3 h-3 mr-0.5" />
                ) : (
                  <TrendingDown className="w-3 h-3 mr-0.5" />
                )}
                {priceChange >= 0 ? '+' : ''}
                {priceChangePercent.toFixed(2)}%
              </span>
            </div>
          )}
        </div>

        {/* Right: Indicator Settings & Tick Simulator */}
        <div className="flex items-center gap-3">
          {/* Signal Mode Label */}
          <div className="hidden lg:flex items-center gap-1.5 text-slate-300 bg-slate-900/80 px-2.5 py-1 rounded border border-slate-800 font-mono text-[11px]">
            <span className="text-slate-400">{isKhmer ? 'របៀបសញ្ញា:' : 'Mode:'}</span>
            <span className="text-teal-400 font-bold">
              {settings.signalMode.split(' ')[0]}
            </span>
            <span className="text-slate-500">· RR {settings.rrRatio}x</span>
          </div>

          {/* Indicator Settings Modal Trigger */}
          <button
            onClick={() => setIsSettingsOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#121927] hover:bg-slate-800 text-slate-200 rounded border border-slate-700 transition-colors"
          >
            <Sliders className="w-3.5 h-3.5 text-teal-400" />
            <span>{isKhmer ? 'ការកំណត់ Indicator' : 'Indicator Settings'}</span>
          </button>

          {/* Tick Simulation Play/Pause */}
          <div className="flex items-center gap-1 bg-[#121927] border border-slate-800 rounded p-0.5">
            <button
              onClick={() => setIsSimulating((prev) => !prev)}
              className={`p-1 rounded transition-colors ${
                isSimulating ? 'text-teal-400 hover:bg-slate-800' : 'text-slate-400 hover:bg-slate-800'
              }`}
              title={isSimulating ? 'Pause Live Ticks' : 'Start Live Ticks'}
            >
              {isSimulating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={() => setSimSpeed((prev) => (prev === 1000 ? 300 : prev === 300 ? 100 : 1000))}
              className="px-2 py-0.5 text-[10px] font-mono font-bold text-slate-300 hover:text-white"
              title="Change Tick Speed"
            >
              {simSpeed === 1000 ? '1x' : simSpeed === 300 ? '3x' : '10x'}
            </button>
          </div>
        </div>
      </div>

      {/* Main Viewport Content */}
      <main className="flex-1 p-4 md:p-6 max-w-[1600px] w-full mx-auto">
        {isLoadingCandles ? (
          <div className="flex flex-col items-center justify-center min-h-[450px] gap-3 text-slate-400">
            <div className="w-7 h-7 border-2 border-teal-500 border-t-transparent rounded-full animate-spin" />
            <span className="text-xs font-mono">
              {isKhmer ? 'កំពុងទាញយកទិន្នន័យតម្លៃ...' : 'Loading market candlestick data...'}
            </span>
          </div>
        ) : (
          <>
            {/* TAB 1: AUTO TRADING BOT DASHBOARD */}
            {activeTab === 'bot' && (
              <AutoTradingBotPanel
                config={botState.config}
                positions={botState.positions}
                closedPositions={botState.closedPositions}
                logs={botState.logs}
                currentPrice={latestCandle ? latestCandle.close : selectedAsset.basePrice}
                symbol={selectedAsset.symbol}
                lang={lang}
              />
            )}

            {/* TAB 2: LIVE TRADING CHART */}
            {activeTab === 'chart' && (
              <div className="flex flex-col gap-4 h-[calc(100vh-170px)] min-h-[580px]">
                <TradingChart
                  candles={candles}
                  indicatorData={indicatorData}
                  settings={settings}
                  activePositions={botState.positions}
                  selectedTradeIndex={selectedTradeIndex}
                  onSelectTrade={setSelectedTradeIndex}
                  decimals={selectedAsset.decimals}
                  symbol={selectedAsset.symbol}
                />
              </div>
            )}

            {/* TAB 3: BACKTEST REPORT */}
            {activeTab === 'backtest' && (
              <BacktestPanel
                metrics={backtestResult.metrics}
                trades={backtestResult.trades}
                onSelectTrade={handleSelectTrade}
                decimals={selectedAsset.decimals}
                symbol={selectedAsset.symbol}
                lang={lang}
              />
            )}

            {/* TAB 4: PINE SCRIPT CODE */}
            {activeTab === 'script' && <PineScriptViewer lang={lang} />}

            {/* TAB 5: ALERTS MONITOR */}
            {activeTab === 'alerts' && (
              <AlertsPanel
                alerts={alerts}
                soundEnabled={soundAlert.enabled}
                onToggleSound={() => {
                  soundAlert.enabled = !soundAlert.enabled;
                  botEngine.updateConfig({ soundAlerts: soundAlert.enabled });
                }}
                decimals={selectedAsset.decimals}
                lang={lang}
              />
            )}
          </>
        )}
      </main>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSave={(newSettings) => setSettings(newSettings)}
        onReset={() => setSettings(DEFAULT_SETTINGS)}
        lang={lang}
      />
    </div>
  );
}
